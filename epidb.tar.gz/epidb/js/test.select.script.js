$(document).ready(function()
{
	$("#species").change(function(){
    	if($("#species").val() == "")
    	{
        	$("#tissue").removeClass('hidden');
    		$('#species option').each(function(){
    			if($(this).val() != "")
    			{
    				$('#tissue'+$(this).val()).addClass('hidden');
    				$('#tissue'+$(this).val()+'rnaseq').addClass('hidden');
    				$('#tissue'+$(this).val()+'mirna').addClass('hidden');
    				$('#tissue'+$(this).val()+'chipseq').addClass('hidden');
    				$('#tissue'+$(this).val()+'methyl').addClass('hidden');
    			}
    		});
        }
        else
        {
        	$("#tissue").addClass('hidden');
        	if($('#datatype').val() == "" || $('#datatype').val() == "all")
        	{
        		$('#tissue'+$('#species').val()).removeClass('hidden');
        		$('#tissue'+$('#species').val()+'rnaseq').addClass('hidden');
    			$('#tissue'+$('#species').val()+'mirna').addClass('hidden');
    			$('#tissue'+$('#species').val()+'chipseq').addClass('hidden');
    			$('#tissue'+$('#species').val()+'methyl').addClass('hidden');
        	}
        	else if($('#datatype').val() == "rnaseq")
        	{
        		$('#tissue'+$('#species').val()).addClass('hidden');
        		$('#tissue'+$('#species').val()+'rnaseq').removeClass('hidden');
    			$('#tissue'+$('#species').val()+'mirna').addClass('hidden');
    			$('#tissue'+$('#species').val()+'chipseq').addClass('hidden');
    			$('#tissue'+$('#species').val()+'methyl').addClass('hidden');
        	}
        	else if($('#datatype').val() == "miRNA")
        	{
        		$('#tissue'+$('#species').val()).addClass('hidden');
        		$('#tissue'+$('#species').val()+'rnaseq').addClass('hidden');
    			$('#tissue'+$('#species').val()+'mirna').removeClass('hidden');
    			$('#tissue'+$('#species').val()+'chipseq').addClass('hidden');
    			$('#tissue'+$('#species').val()+'methyl').addClass('hidden');
        	}
        	else if($('#datatype').val() == "chipseq")
        	{
        		$('#tissue'+$('#species').val()).addClass('hidden');
        		$('#tissue'+$('#species').val()+'rnaseq').addClass('hidden');
    			$('#tissue'+$('#species').val()+'mirna').addClass('hidden');
    			$('#tissue'+$('#species').val()+'chipseq').removeClass('hidden');
    			$('#tissue'+$('#species').val()+'methyl').addClass('hidden');
        	}
        	else if($('#datatype').val() == "methyl")
        	{
        		$('#tissue'+$('#species').val()).addClass('hidden');
        		$('#tissue'+$('#species').val()+'rnaseq').addClass('hidden');
    			$('#tissue'+$('#species').val()+'mirna').addClass('hidden');
    			$('#tissue'+$('#species').val()+'chipseq').addClass('hidden');
    			$('#tissue'+$('#species').val()+'methyl').removeClass('hidden');
        	}
        	$('#species option').each(function(){
        		if($(this).val() != "" && $(this).val() != $('#species').val())
    			{
    				$('#tissue'+$(this).val()).addClass('hidden');
    				$('#tissue'+$(this).val()+'rnaseq').addClass('hidden');
    				$('#tissue'+$(this).val()+'mirna').addClass('hidden');
    				$('#tissue'+$(this).val()+'chipseq').addClass('hidden');
    				$('#tissue'+$(this).val()+'methyl').addClass('hidden');
    			}
    		});
        }
    });
    
    $("#datatype").change(function(){
    	if($('#species').val() != "")
    	{
    		if($('#datatype').val() == "" || $('#datatype').val() == "all")
    		{
    			$('#tissue'+$('#species').val()).removeClass('hidden');
        		$('#tissue'+$('#species').val()+'rnaseq').addClass('hidden');
    			$('#tissue'+$('#species').val()+'mirna').addClass('hidden');
    			$('#tissue'+$('#species').val()+'chipseq').addClass('hidden');
    			$('#tissue'+$('#species').val()+'methyl').addClass('hidden');
    		}
    		else if($('#datatype').val() == "rnaseq")
    		{
    			$('#tissue'+$('#species').val()).addClass('hidden');
        		$('#tissue'+$('#species').val()+'rnaseq').removeClass('hidden');
    			$('#tissue'+$('#species').val()+'mirna').addClass('hidden');
    			$('#tissue'+$('#species').val()+'chipseq').addClass('hidden');
    			$('#tissue'+$('#species').val()+'methyl').addClass('hidden');
    		}
    		else if($('#datatype').val() == "miRNA")
    		{
    			$('#tissue'+$('#species').val()).addClass('hidden');
        		$('#tissue'+$('#species').val()+'rnaseq').addClass('hidden');
    			$('#tissue'+$('#species').val()+'mirna').removeClass('hidden');
    			$('#tissue'+$('#species').val()+'chipseq').addClass('hidden');
    			$('#tissue'+$('#species').val()+'methyl').addClass('hidden');
    		}
    		else if($('#datatype').val() == "chipseq")
    		{
    			$('#tissue'+$('#species').val()).addClass('hidden');
        		$('#tissue'+$('#species').val()+'rnaseq').addClass('hidden');
    			$('#tissue'+$('#species').val()+'mirna').addClass('hidden');
    			$('#tissue'+$('#species').val()+'chipseq').removeClass('hidden');
    			$('#tissue'+$('#species').val()+'methyl').addClass('hidden');
    		}
    		else if($('#datatype').val() == "methyl")
    		{
    			$('#tissue'+$('#species').val()).addClass('hidden');
        		$('#tissue'+$('#species').val()+'rnaseq').addClass('hidden');
    			$('#tissue'+$('#species').val()+'mirna').addClass('hidden');
    			$('#tissue'+$('#species').val()+'chipseq').addClass('hidden');
    			$('#tissue'+$('#species').val()+'methyl').removeClass('hidden');
    		}
    	}
    	else
    	{
    		$("#tissue").removeClass('hidden');
    		$('#species option').each(function(){
    			if($(this).val() != "")
    			{
    				$('#tissue'+$(this).val()).addClass('hidden');
    				$('#tissue'+$(this).val()+'rnaseq').addClass('hidden');
    				$('#tissue'+$(this).val()+'mirna').addClass('hidden');
    				$('#tissue'+$(this).val()+'chipseq').addClass('hidden');
    				$('#tissue'+$(this).val()+'methyl').addClass('hidden');
    			}
    		});
    	}
    });
    
});