<?php
  $trialarray = array();
  
  $sqltrial = "SELECT Trial_ID, TrialName FROM Trial";
  
  $querytrial = mysql_query($sqltrial, $connect) or die(mysql_error());
  while($row = mysql_fetch_assoc($querytrial))
  {
    extract($row);
    $trialid = $row["Trial_ID"];
    $trialname = $row["TrialName"];
    if(!($trialname == "Big Pig"))
    {
    	$tmptrial = array($trialid, $trialname);
    	$trialarray[] = $tmptrial;
    }
  }
?>