<?php $currentPage = basename($_SERVER['SCRIPT_NAME']); ?>
<header class="navbar navbar-inverse navbar-static-top bs-docs-nav" role="banner">
	<div class="container">
		<div class="navbar-header">
    		<a class="navbar-brand" href="#">
    			EpiDB
			</a>
		</div>
		<nav class="collapse navbar-collapse bs-navbar-collapse" role="navigation">
			<ul class="nav navbar-nav">
  				<li <?php if($currentPage == 'index.php') {echo 'class="active"';} ?>><a href="index.php">Home</a></li>
  				<li <?php if($currentPage == 'data.php') {echo 'class="active"';} ?>><a href="data.php">Data</a></li>
  				<li <?php if($currentPage == 'search.php') {echo 'class="active"';} ?>><a href="search.php">Search</a></li>
			</ul>
		</nav>
	</div>
</header>