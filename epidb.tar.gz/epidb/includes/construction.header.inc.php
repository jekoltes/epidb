<div class="navbar">
	<div class="navbar-inner">
    	<div class="container">
    		<a class="brand" href="#">
    			PHGC Database
			</a>
			<ul class="nav">
  				<li><a href="">Home</a></li>
  				<li><a href="">News</a></li>
  				<li><a href=""><i class="icon-user icon-white"></i>Login</a></li>
			</ul>
    	</div>
	</div>
</div>