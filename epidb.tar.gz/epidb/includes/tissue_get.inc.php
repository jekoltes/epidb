<?php
  $tissuearray = array();
  
  $sqltissue = "SELECT Tissue_ID, Tissue FROM Tissue";
  
  $querytissue = mysql_query($sqltissue, $connect) or die(mysql_error());
  while($row = mysql_fetch_assoc($querytissue))
  {
    extract($row);
    $tissueid = $row["Tissue_ID"];
    $tissue = $row["Tissue"];
    $temptissue = array($tissueid, $tissue);
    $tissuearray[] = $temptissue;
  }
?>