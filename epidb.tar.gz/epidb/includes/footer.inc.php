<div class="navbar navbar-default navbar-static-bottom" role="banner">
	<div class="container">
    	<nav class="collapse navbar-collapse" role="navigation">
    		<div class="col-md-3">	
    				<h5>&copy;<?php ini_set('date.timezone','America/Chicago'); $startYear = 2014; $thisYear = date(Y); if($startYear == $thisYear){echo $startYear;}else{echo "{$startYear}-{$thisYear}";}?></h5>
    				<h5>Eric Fritz-Waters</h5>
    				<h5>Email: ercfrtz@iastate.edu</h5>
    				<p>This website runs on <a href="http://twitter.github.com/bootstrap/index.html">Bootstrap</a></p>
    		</div>
    		<div class="col-md-8">
        		<br/>
        		<h5>The EpiDB is a database designed to host epigenetics data and is the project of Dr. James Koltes.</h5>
        		<h5>Acknowledgements: This work is funded by a NIFA Post-Doctoral Fellowship. <img src="images/usda.logo.jpg" /></h5>
        	</div>
    	</nav>
	</div>
</div>