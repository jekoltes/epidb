<?php
session_start();
if(!isset($_SESSION['authenticated']))
{
  header('Location: http://www.animalgenome.org/lunney/login.php');
  exit;
}
include('includes/title.inc.php');

$connect = mysql_connect('localhost','eric','LushPed07');
mysql_select_db("host_lunneylab2", $connect);

if(array_key_exists('searchbyphenotype', $_POST))
{
	$trialsearch = $_POST['trialphenotype'];
	$classificationsearch = $_POST['classificationphenotype'];
	$gendersearch = $_POST['genderphenotype'];
	$tissuesearch = $_POST['tissuephenotype'];
	$outputoption = $_POST['outputoption'];
	  
	
  	$phenotypeSearchArgs = "perl /home/users/ercfrtz/PhenotypeSearch.pl";
    $filename = "/tmp/phenotypeSearchResults".time().".txt";
    $_SESSION['SearchFile'] = $filename;
    $phenotypeSearchArgs .= " -o ".$filename;
    if($trialsearch != "")
    	{$phenotypeSearchArgs .= " -t ".$trialsearch;}
    if($classificationsearch != "")
    	{$phenotypeSearchArgs .= " -c ".$classificationsearch;}
    if($gendersearch != "")
    	{$phenotypeSearchArgs .= " -g ".$gendersearch;}
    if($tissuesearch != "")
    	{$phenotypeSearchArgs .= " -k ".$tissuesearch;}
    		
    if($outputoption == "pedigree")
    	{$phenotypeSearchArgs .= " -p pedigree";}
    elseif($outputoption == "weight")
    	{$phenotypeSearchArgs .= " -w weight";}
    if($outputoption == "viral")
    	{$phenotypeSearchArgs .= " -v viral";}
    	
    system($phenotypeSearchArgs);
    
    header('Location: http://www.animalgenome.org/lunney/phgc_search_results.php');
	exit;
}
elseif(array_key_exists('searchbygenotype', $_POST))
{
	$trialsearch = $_POST['trialgenotype'];
	$classificationsearch = $_POST['classificationgenotype'];
	$gendersearch = $_POST['gendergenotype'];
	$tissuesearch = $_POST['tissuegenotype'];
	$genotypeformat = $_POST['genotypeformat'];
	
    $genotypeSearchArgs = "perl /home/users/ercfrtz/newGenotypeSearch.pl";
    $filename = "/tmp/genotypeSearchResults".time().".txt";
    $_SESSION['SearchFile'] = $filename;
    $genotypeSearchArgs .= " -o ".$filename;
    if($trialsearch != "")
    	{$genotypeSearchArgs .= " -t ".$trialsearch;}
    if($classificationsearch != "")
    	{$genotypeSearchArgs .= " -c ".$classificationsearch;}
    if($gendersearch != "")
    	{$genotypeSearchArgs .= " -g ".$gendersearch;}
    if($tissuesearch != "")
    	{$genotypeSearchArgs .= " -k ".$tissuesearch;}
    if($genotypeformat != "")
    	{$genotypeSearchArgs .= " -f ".$genotypeformat;}
    	
    system($genotypeSearchArgs);
    
    header('Location: http://www.animalgenome.org/lunney/phgc_search_results.php');
	exit;
}
elseif(array_key_exists('searchbygene', $_POST))
{
	$trialsearch = $_POST['trialgene'];
	$classificationsearch = $_POST['classificationgene'];
	$gendersearch = $_POST['gendergene'];
	$tissuesearch = $_POST['tissuegene'];
	
	$geneSearchArgs = "perl /home/users/ercfrtz/GeneSearch.pl";
    $filename = "/tmp/geneSearchResults".time().".txt";
    $_SESSION['SearchFile'] = $filename;
    $geneSearchArgs .= " -o ".$filename;
    if($trialsearch != "")
    	{$geneSearchArgs .= " -t ".$trialsearch;}
    if($classificationsearch != "")
    	{$geneSearchArgs .= " -c ".$classificationsearch;}
    if($gendersearch != "")
    	{$geneSearchArgs .= " -g ".$gendersearch;}
    if($tissuesearch != "")
    	{$geneSearchArgs .= " -k ".$tissuesearch;}
    	
    system($geneSearchArgs);
    
    header('Location: http://www.animalgenome.org/lunney/phgc_search_results.php');
	exit;
}
elseif(array_key_exists('searchbyindividual', $_POST))
{
	$upnsearch = $_POST['individualupn'];
	header('Location: http://www.animalgenome.org/lunney/individual_results.php?upn='.$upnsearch);
	exit;
}
?>