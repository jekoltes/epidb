#!/usr/bin/perl

use warnings;
use strict;
use DBI;
use DateTime;
use DateTime::Format::MySQL;
 
my $animalid = "12161";
my $date = "2012-10-18";
my $birthdate = "2012-03-29";
my $damage = "2002-04-09";
my $value = 530;
my $Bvalue = 85;
			
				my $dt1 = DateTime::Format::MySQL->parse_datetime($date." 00:00:00");
				my $dt2 = DateTime::Format::MySQL->parse_datetime($birthdate." 00:00:00");
				my $dt3 = DateTime::Format::MySQL->parse_datetime($damage." 00:00:00");
				my $dtdifference = $dt1->delta_days( $dt2 );
				my $wage = $dtdifference->delta_days;
				my $cdifference = $dt2->delta_days( $dt3 );
				my $cage = $cdifference->delta_days;
				
					my $adjWeight = (((($value-$Bvalue)/$wage)*205)+$Bvalue);
					if($cage < 974)
					{
						if($sex eq "B" || $sex eq "S" || $sex eq "M")
							{$adjWeight += 68;}
						elsif($sex eq "C" || $sex eq "F")
							{$adjWeight += 57;}
					}
					elsif($cage > 973 && $cage < 1187)
					{
						if($sex eq "B" || $sex eq "S" || $sex eq "M")
							{$adjWeight += 67;}
						elsif($sex eq "C" || $sex eq "F")
							{$adjWeight += 55;}
					}
					elsif($cage > 1186 && $cage < 1369)
					{
						if($sex eq "B" || $sex eq "S" || $sex eq "M")
							{$adjWeight += 37;}
						elsif($sex eq "C" || $sex eq "F")
							{$adjWeight += 32;}
					}
					elsif($cage > 1368 && $cage < 1552)
					{
						if($sex eq "B" || $sex eq "S" || $sex eq "M")
							{$adjWeight += 29;}
						elsif($sex eq "C" || $sex eq "F")
							{$adjWeight += 21;}
					}
					elsif($cage > 1551 && $cage < 1917)
					{
						if($sex eq "B" || $sex eq "S" || $sex eq "M")
							{$adjWeight += 15;}
						elsif($sex eq "C" || $sex eq "F")
							{$adjWeight += 13;}
					}
					elsif($cage > 1916 && $cage < 3742)
					{
						if($sex eq "B" || $sex eq "S" || $sex eq "M")
							{$adjWeight += 0;}
						elsif($sex eq "C" || $sex eq "F")
							{$adjWeight += 0;}
					}
					elsif($cage > 3741)
					{
						if($sex eq "B" || $sex eq "S" || $sex eq "M")
							{$adjWeight += 22;}
						elsif($sex eq "C" || $sex eq "F")
							{$adjWeight += 19;}
					}
					print $animalID."\t".$date."\t".$adjWeight."\n";


