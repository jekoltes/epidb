<?php
session_start();

include('includes/title.inc.php');

$connect = mysql_connect('localhost:/data/mysql/mysql.sock', "eric", "R1ftw4lker");
mysql_select_db("EpiDB");

$speciesSNameArray = array();
$speciesCNameArray = array();
$speciesIDArray = array();
$tissueNameArray = array();
$tissueIDArray = array();
$speciesCount = 0;
$tissueCount = 0;

$sqlSpecies = "SELECT * FROM EpiDB_Species";
$resultsSpecies = mysql_query($sqlSpecies,$connect) or die(mysql_error());
while($rowSpecies = mysql_fetch_array($resultsSpecies))
{
	$speciesIDArray[$speciesCount] = $rowSpecies['species_ID'];
	$speciesSNameArray[$speciesCount] = $rowSpecies['species_sname'];
	$speciesCNameArray[$speciesCount] = $rowSpecies['species_cname'];
	$speciesCount++;
}
	
$sqlTissue = "SELECT * from EpiDB_Tissues";
$resultsTissue = mysql_query($sqlTissue,$connect) or die(mysql_error());
while($rowTissue = mysql_fetch_array($resultsTissue))
{
	$tissueNameArray[$tissueCount] = $rowTissue['tissuetype'];
	$tissueIDArray[$tissueCount] = $rowTissue['tissue_ID'];
	$tissueCount++;
}

if(array_key_exists('search', $_POST))
{
	$tempSpecies = $_POST['species'];
	$tempDataType = $_POST['datatype'];
	
	if($tempDataType == "" || $tempDataType == "all")
		{$tempTissue =  $_POST["tissue".$tempSpecies];}
	elseif($tempDataType == "rnaseq")
		{$tempTissue = $_POST["tissue".$tempSpecies."rnaseq"];}
	elseif($tempDataType == "miRNA")
		{$tempTissue = $_POST["tissue".$tempSpecies."mirna"];}
	elseif($tempDataType == "chipseq")
		{$tempTissue = $_POST["tissue".$tempSpecies."chipseq"];}
	elseif($tempDataType == "methyl")
		{$tempTissue = $_POST["tissue".$tempSpecies."methyl"];}
	
	
	$rnaseqArray = array();
	$chipseqArray = array();
	$miRNAArray = array();
	$methylArray = array();
	$rnaseqCount = 0;
	$chipseqCount = 0;
	$mirnaCount = 0;
	$methylCount = 0;
	
	$currentTime = time();
	$rnaseqFile = '/tmp/RNAseq.'.$currentTime.'.txt';
	$chipseqFile = '/tmp/ChIPseq.'.$currentTime.'.txt';
	$mirnaFile = '/tmp/miRNA.'.$currentTime.'.txt';
	$methylFile = '/tmp/Methylation.'.$currentTime.'.txt';
	$rnaseqHandle = fopen($rnaseqFile,w) or die('Cannot open file: '.$rnaseqFile);
	$chipseqHandle = fopen($chipseqFile,w) or die('Cannot open file: '.$chipseqFile);
	$mirnaHandle = fopen($mirnaFile,w) or die('Cannot open file: '.$mirnaFile);
	$methylHandle = fopen($methylFile,w) or die('Cannot open file: '.$methylFile);
	
	if($tempTissue == "all")
	{
	if($tempDataType == "all")
	{
		$sqlRNAseq = "SELECT * FROM EpiDB_rnaseq_track WHERE species_ID='".$tempSpecies."' ORDER BY SRA_experiment_id";
		$resultsRNAseq = mysql_query($sqlRNAseq,$connect) or die(mysql_error());
		while($rowRNAseq = mysql_fetch_array($resultsRNAseq))
		{
			$rnaseqArray[$rnaseqCount] = $rowRNAseq["SRA_experiment_id"]."\t".$rowRNAseq["tissue_ID"];
			if($rowRNAseq["study_title"] != null)
				{$rnaseqArray[$rnaseqCount] .= "\t".$rowRNAseq["study_title"];}
			else
				{$rnaseqArray[$rnaseqCount] .= "\tNA";}
			if($rowRNAseq["NumberOfBases"] != null)
				{$rnaseqArray[$rnaseqCount] .= "\t".$rowRNAseq["NumberOfBases"];}
			else
				{$rnaseqArray[$rnaseqCount] .= "\tNA";}
			if($rowRNAseq["library_layout"] != null)
				{$rnaseqArray[$rnaseqCount] .= "\t".$rowRNAseq["library_layout"];}
			else
				{$rnaseqArray[$rnaseqCount] .= "\tNA";}
			if($rowRNAseq["submission_date"] != null)
				{$rnaseqArray[$rnaseqCount] .= "\t".$rowRNAseq["submission_date"];}
			else
				{$rnaseqArray[$rnaseqCount] .= "\tNA";}
			if($rowRNAseq["GEO_GSM_ID"] != null)
				{$rnaseqArray[$rnaseqCount] .= "\t".$rowRNAseq["GEO_GSM_ID"];}
			else
				{$rnaseqArray[$rnaseqCount] .= "\tNA";}
			if($rowRNAseq["GEO_GSE_ID"] != null)
				{$rnaseqArray[$rnaseqCount] .= "\t".$rowRNAseq["GEO_GSE_ID"];}
			else
				{$rnaseqArray[$rnaseqCount] .= "\tNA";}
			if($rowRNAseq["sample_attribute"] != null)
				{$rnaseqArray[$rnaseqCount] .= "\t".$rowRNAseq["sample_attribute"];}
			else
				{$rnaseqArray[$rnaseqCount] .= "\tNA";}
			if($rowRNAseq["SRA_study_id"] != null)
				{$rnaseqArray[$rnaseqCount] .= "\t".$rowRNAseq["SRA_study_id"];}
			else
				{$rnaseqArray[$rnaseqCount] .= "\tNA";}
			
			$rnaseqFileOutput = $rowRNAseq[0];
			for($i = 1; $i < count($rowRNAseq); $i++)
			{
				$rnaseqFileOutput .= "\t".$rowRNAseq[$i];
			}
			fwrite($rnaseqHandle, $rnaseqFileOutput."\n");
			$rnaseqCount++;
		}
		$sqlChIPseq = "SELECT * FROM EpiDB_chipseq_track WHERE species_ID='".$tempSpecies."' ORDER BY SRA_experiment_id";
		$resultsChIPseq = mysql_query($sqlChIPseq,$connect) or die(mysql_error());
		while($rowChIPseq = mysql_fetch_array($resultsChIPseq))
		{
			$chipseqArray[$chipseqCount] = $rowChIPseq["SRA_experiment_id"]."\t".$rowChIPseq["tissue_ID"];
			if($rowChIPseq["study_title"] != null)
				{$chipseqArray[$chipseqCount] .= "\t".$rowChIPseq["study_title"];}
			else
				{$chipseqArray[$chipseqCount] .= "\tNA";}
			if($rowChIPseq["NumberOfBases"] != null)
				{$chipseqArray[$chipseqCount] .= "\t".$rowChIPseq["NumberOfBases"];}
			else
				{$chipseqArray[$chipseqCount] .= "\tNA";}
			if($rowChIPseq["library_layout"] != null)
				{$chipseqArray[$chipseqCount] .= "\t".$rowChIPseq["library_layout"];}
			else
				{$chipseqArray[$chipseqCount] .= "\tNA";}
			if($rowChIPseq["submission_date"] != null)
				{$chipseqArray[$chipseqCount] .= "\t".$rowChIPseq["submission_date"];}
			else
				{$chipseqArray[$chipseqCount] .= "\tNA";}
			if($rowChIPseq["GEO_GSM_ID"] != null)
				{$chipseqArray[$chipseqCount] .= "\t".$rowChIPseq["GEO_GSM_ID"];}
			else
				{$chipseqArray[$chipseqCount] .= "\tNA";}
			if($rowChIPseq["GEO_GSE_ID"] != null)
				{$chipseqArray[$chipseqCount] .= "\t".$rowChIPseq["GEO_GSE_ID"];}
			else
				{$chipseqArray[$chipseqCount] .= "\tNA";}
			if($rowChIPseq["sample_attribute"] != null)
				{$chipseqArray[$chipseqCount] .= "\t".$rowChIPseq["sample_attribute"];}
			else
				{$chipseqArray[$chipseqCount] .= "\tNA";}
			if($rowChIPseq["SRA_study_id"] != null)
				{$chipseqArray[$chipseqCount] .= "\t".$rowChIPseq["SRA_study_id"];}
			else
				{$chipseqArray[$chipseqCount] .= "\tNA";}
			
			$chipseqFileOutput = $rowChIPseq[0];
			for($i = 1; $i < count($rowChIPseq); $i++)
			{
				$chipseqFileOutput .= "\t".$rowChIPseq[$i];
			}
			fwrite($chipseqHandle, $chipseqFileOutput."\n");
			$chipseqCount++;
		}
		$sqlmiRNA = "SELECT * FROM EpiDB_miRNA_track WHERE species_ID='".$tempSpecies."' ORDER BY SRA_experiment_id";
		$resultsmiRNA = mysql_query($sqlmiRNA,$connect) or die(mysql_error());
		while($rowmiRNA = mysql_fetch_array($resultsmiRNA))
		{
			$mirnaArray[$mirnaCount] = $rowmiRNA["SRA_experiment_id"]."\t".$rowmiRNA["tissue_ID"];
			if($rowmiRNA["study_title"] != null)
				{$mirnaArray[$mirnaCount] .= "\t".$rowmiRNA["study_title"];}
			else
				{$mirnaArray[$mirnaCount] .= "\tNA";}
			if($rowmiRNA["NumberOfBases"] != null)
				{$mirnaArray[$mirnaCount] .= "\t".$rowmiRNA["NumberOfBases"];}
			else
				{$mirnaArray[$mirnaCount] .= "\tNA";}
			if($rowmiRNA["library_layout"] != null)
				{$mirnaArray[$mirnaCount] .= "\t".$rowmiRNA["library_layout"];}
			else
				{$mirnaArray[$mirnaCount] .= "\tNA";}
			if($rowmiRNA["submission_date"] != null)
				{$mirnaArray[$mirnaCount] .= "\t".$rowmiRNA["submission_date"];}
			else
				{$mirnaArray[$mirnaCount] .= "\tNA";}
			if($rowmiRNA["GEO_GSM_ID"] != null)
				{$mirnaArray[$mirnaCount] .= "\t".$rowmiRNA["GEO_GSM_ID"];}
			else
				{$mirnaArray[$mirnaCount] .= "\tNA";}
			if($rowmiRNA["GEO_GSE_ID"] != null)
				{$mirnaArray[$mirnaCount] .= "\t".$rowmiRNA["GEO_GSE_ID"];}
			else
				{$mirnaArray[$mirnaCount] .= "\tNA";}
			if($rowmiRNA["sample_attribute"] != null)
				{$mirnaArray[$mirnaCount] .= "\t".$rowmiRNA["sample_attribute"];}
			else
				{$mirnaArray[$mirnaCount] .= "\tNA";}
			if($rowmiRNA["SRA_study_id"] != null)
				{$mirnaArray[$mirnaCount] .= "\t".$rowmiRNA["SRA_study_id"];}
			else
				{$mirnaArray[$mirnaCount] .= "\tNA";}
			
			$mirnaFileOutput = $rowmiRNA[0];
			for($i = 1; $i < count($rowmiRNA); $i++)
			{
				$mirnaFileOutput .= "\t".$rowmiRNA[$i];
			}
			fwrite($mirnaHandle, $mirnaFileOutput."\n");
			$mirnaCount++;
		}
		$sqlmethyl = "SELECT * FROM EpiDB_Methyl_track WHERE species_ID='".$tempSpecies."' ORDER BY SRA_experiment_id";
		$resultsmethyl = mysql_query($sqlmethyl,$connect) or die(mysql_error());
		while($rowmethyl = mysql_fetch_array($resultsmethyl))
		{
			$methylArray[$methylCount] = $rowmethyl["SRA_experiment_id"]."\t".$rowmethyl["tissue_ID"];
			if($rowmethyl["study_title"] != null)
				{$methylArray[$methylCount] .= "\t".$rowmethyl["study_title"];}
			else
				{$methylArray[$methylCount] .= "\tNA";}
			if($rowmethyl["NumberOfBases"] != null)
				{$methylArray[$methylCount] .= "\t".$rowmethyl["NumberOfBases"];}
			else
				{$methylArray[$methylCount] .= "\tNA";}
			if($rowmethyl["library_layout"] != null)
				{$methylArray[$methylCount] .= "\t".$rowmethyl["library_layout"];}
			else
				{$methylArray[$methylCount] .= "\tNA";}
			if($rowmethyl["submission_date"] != null)
				{$methylArray[$methylCount] .= "\t".$rowmethyl["submission_date"];}
			else
				{$methylArray[$methylCount] .= "\tNA";}
			if($rowmethyl["GEO_GSM_ID"] != null)
				{$methylArray[$methylCount] .= "\t".$rowmethyl["GEO_GSM_ID"];}
			else
				{$methylArray[$methylCount] .= "\tNA";}
			if($rowmethyl["GEO_GSE_ID"] != null)
				{$methylArray[$methylCount] .= "\t".$rowmethyl["GEO_GSE_ID"];}
			else
				{$methylArray[$methylCount] .= "\tNA";}
			if($rowmethyl["sample_attribute"] != null)
				{$methylArray[$methylCount] .= "\t".$rowmethyl["sample_attribute"];}
			else
				{$methylArray[$methylCount] .= "\tNA";}
			if($rowmethyl["SRA_study_id"] != null)
				{$methylArray[$methylCount] .= "\t".$rowmethyl["SRA_study_id"];}
			else
				{$methylArray[$methylCount] .= "\tNA";}
			
			$methylFileOutput = $rowmethyl[0];
			for($i = 1; $i < count($rowmethyl); $i++)
			{
				$methylFileOutput .= "\t".$rowmethyl[$i];
			}
			fwrite($methylHandle, $methylFileOutput."\n");
			$methylCount++;
		}
	}
	elseif($tempDataType == "rnaseq")
	{
		$sqlRNAseq = "SELECT * FROM EpiDB_rnaseq_track WHERE species_ID='".$tempSpecies."' ORDER BY SRA_experiment_id";
		$resultsRNAseq = mysql_query($sqlRNAseq,$connect) or die(mysql_error());
		while($rowRNAseq = mysql_fetch_array($resultsRNAseq))
		{
			$rnaseqArray[$rnaseqCount] = $rowRNAseq["SRA_experiment_id"]."\t".$rowRNAseq["tissue_ID"];
			if($rowRNAseq["study_title"] != null)
				{$rnaseqArray[$rnaseqCount] .= "\t".$rowRNAseq["study_title"];}
			else
				{$rnaseqArray[$rnaseqCount] .= "\tNA";}
			if($rowRNAseq["NumberOfBases"] != null)
				{$rnaseqArray[$rnaseqCount] .= "\t".$rowRNAseq["NumberOfBases"];}
			else
				{$rnaseqArray[$rnaseqCount] .= "\tNA";}
			if($rowRNAseq["library_layout"] != null)
				{$rnaseqArray[$rnaseqCount] .= "\t".$rowRNAseq["library_layout"];}
			else
				{$rnaseqArray[$rnaseqCount] .= "\tNA";}
			if($rowRNAseq["submission_date"] != null)
				{$rnaseqArray[$rnaseqCount] .= "\t".$rowRNAseq["submission_date"];}
			else
				{$rnaseqArray[$rnaseqCount] .= "\tNA";}
			if($rowRNAseq["GEO_GSM_ID"] != null)
				{$rnaseqArray[$rnaseqCount] .= "\t".$rowRNAseq["GEO_GSM_ID"];}
			else
				{$rnaseqArray[$rnaseqCount] .= "\tNA";}
			if($rowRNAseq["GEO_GSE_ID"] != null)
				{$rnaseqArray[$rnaseqCount] .= "\t".$rowRNAseq["GEO_GSE_ID"];}
			else
				{$rnaseqArray[$rnaseqCount] .= "\tNA";}
			if($rowRNAseq["sample_attribute"] != null)
				{$rnaseqArray[$rnaseqCount] .= "\t".$rowRNAseq["sample_attribute"];}
			else
				{$rnaseqArray[$rnaseqCount] .= "\tNA";}
			if($rowRNAseq["SRA_study_id"] != null)
				{$rnaseqArray[$rnaseqCount] .= "\t".$rowRNAseq["SRA_study_id"];}
			else
				{$rnaseqArray[$rnaseqCount] .= "\tNA";}
			
			$rnaseqFileOutput = $rowRNAseq[0];
			for($i = 1; $i < count($rowRNAseq); $i++)
			{
				$rnaseqFileOutput .= "\t".$rowRNAseq[$i];
			}
			fwrite($rnaseqHandle, $rnaseqFileOutput."\n");
			$rnaseqCount++;
		}
	}
	elseif($tempDataType == "chipseq")
	{
		$sqlChIPseq = "SELECT * FROM EpiDB_chipseq_track WHERE species_ID='".$tempSpecies."' ORDER BY SRA_experiment_id";
		$resultsChIPseq = mysql_query($sqlChIPseq,$connect) or die(mysql_error());
		while($rowChIPseq = mysql_fetch_array($resultsChIPseq))
		{
			$chipseqArray[$chipseqCount] = $rowChIPseq["SRA_experiment_id"]."\t".$rowChIPseq["tissue_ID"];
			if($rowChIPseq["study_title"] != null)
				{$chipseqArray[$chipseqCount] .= "\t".$rowChIPseq["study_title"];}
			else
				{$chipseqArray[$chipseqCount] .= "\tNA";}
			if($rowChIPseq["NumberOfBases"] != null)
				{$chipseqArray[$chipseqCount] .= "\t".$rowChIPseq["NumberOfBases"];}
			else
				{$chipseqArray[$chipseqCount] .= "\tNA";}
			if($rowChIPseq["library_layout"] != null)
				{$chipseqArray[$chipseqCount] .= "\t".$rowChIPseq["library_layout"];}
			else
				{$chipseqArray[$chipseqCount] .= "\tNA";}
			if($rowChIPseq["submission_date"] != null)
				{$chipseqArray[$chipseqCount] .= "\t".$rowChIPseq["submission_date"];}
			else
				{$chipseqArray[$chipseqCount] .= "\tNA";}
			if($rowChIPseq["GEO_GSM_ID"] != null)
				{$chipseqArray[$chipseqCount] .= "\t".$rowChIPseq["GEO_GSM_ID"];}
			else
				{$chipseqArray[$chipseqCount] .= "\tNA";}
			if($rowChIPseq["GEO_GSE_ID"] != null)
				{$chipseqArray[$chipseqCount] .= "\t".$rowChIPseq["GEO_GSE_ID"];}
			else
				{$chipseqArray[$chipseqCount] .= "\tNA";}
			if($rowChIPseq["sample_attribute"] != null)
				{$chipseqArray[$chipseqCount] .= "\t".$rowChIPseq["sample_attribute"];}
			else
				{$chipseqArray[$chipseqCount] .= "\tNA";}
			if($rowChIPseq["SRA_study_id"] != null)
				{$chipseqArray[$chipseqCount] .= "\t".$rowChIPseq["SRA_study_id"];}
			else
				{$chipseqArray[$chipseqCount] .= "\tNA";}
			
			$chipseqFileOutput = $rowChIPseq[0];
			for($i = 1; $i < count($rowChIPseq); $i++)
			{
				$chipseqFileOutput .= "\t".$rowChIPseq[$i];
			}
			fwrite($chipseqHandle, $chipseqFileOutput."\n");
			$chipseqCount++;
		}
	}
	elseif($tempDataType == "miRNA")
	{
		$sqlmiRNA = "SELECT * FROM EpiDB_miRNA_track WHERE species_ID='".$tempSpecies."' ORDER BY SRA_experiment_id";
		$resultsmiRNA = mysql_query($sqlmiRNA,$connect) or die(mysql_error());
		while($rowmiRNA = mysql_fetch_array($resultsmiRNA))
		{
			$mirnaArray[$mirnaCount] = $rowmiRNA["SRA_experiment_id"]."\t".$rowmiRNA["tissue_ID"];
			if($rowmiRNA["study_title"] != null)
				{$mirnaArray[$mirnaCount] .= "\t".$rowmiRNA["study_title"];}
			else
				{$mirnaArray[$mirnaCount] .= "\tNA";}
			if($rowmiRNA["NumberOfBases"] != null)
				{$mirnaArray[$mirnaCount] .= "\t".$rowmiRNA["NumberOfBases"];}
			else
				{$mirnaArray[$mirnaCount] .= "\tNA";}
			if($rowmiRNA["library_layout"] != null)
				{$mirnaArray[$mirnaCount] .= "\t".$rowmiRNA["library_layout"];}
			else
				{$mirnaArray[$mirnaCount] .= "\tNA";}
			if($rowmiRNA["submission_date"] != null)
				{$mirnaArray[$mirnaCount] .= "\t".$rowmiRNA["submission_date"];}
			else
				{$mirnaArray[$mirnaCount] .= "\tNA";}
			if($rowmiRNA["GEO_GSM_ID"] != null)
				{$mirnaArray[$mirnaCount] .= "\t".$rowmiRNA["GEO_GSM_ID"];}
			else
				{$mirnaArray[$mirnaCount] .= "\tNA";}
			if($rowmiRNA["GEO_GSE_ID"] != null)
				{$mirnaArray[$mirnaCount] .= "\t".$rowmiRNA["GEO_GSE_ID"];}
			else
				{$mirnaArray[$mirnaCount] .= "\tNA";}
			if($rowmiRNA["sample_attribute"] != null)
				{$mirnaArray[$mirnaCount] .= "\t".$rowmiRNA["sample_attribute"];}
			else
				{$mirnaArray[$mirnaCount] .= "\tNA";}
			if($rowmiRNA["SRA_study_id"] != null)
				{$mirnaArray[$mirnaCount] .= "\t".$rowmiRNA["SRA_study_id"];}
			else
				{$mirnaArray[$mirnaCount] .= "\tNA";}
			
			$mirnaFileOutput = $rowmiRNA[0];
			for($i = 1; $i < count($rowmiRNA); $i++)
			{
				$mirnaFileOutput .= "\t".$rowmiRNA[$i];
			}
			fwrite($mirnaHandle, $mirnaFileOutput."\n");
			$mirnaCount++;
		}
	}
	elseif($tempDataType == "methyl")
	{
		$sqlmethyl = "SELECT * FROM EpiDB_Methyl_track WHERE species_ID='".$tempSpecies."' ORDER BY SRA_experiment_id";
		$resultsmethyl = mysql_query($sqlmethyl,$connect) or die(mysql_error());
		while($rowmethyl = mysql_fetch_array($resultsmethyl))
		{
			$methylArray[$methylCount] = $rowmethyl["SRA_experiment_id"]."\t".$rowmethyl["tissue_ID"];
			if($rowmethyl["study_title"] != null)
				{$methylArray[$methylCount] .= "\t".$rowmethyl["study_title"];}
			else
				{$methylArray[$methylCount] .= "\tNA";}
			if($rowmethyl["NumberOfBases"] != null)
				{$methylArray[$methylCount] .= "\t".$rowmethyl["NumberOfBases"];}
			else
				{$methylArray[$methylCount] .= "\tNA";}
			if($rowmethyl["library_layout"] != null)
				{$methylArray[$methylCount] .= "\t".$rowmethyl["library_layout"];}
			else
				{$methylArray[$methylCount] .= "\tNA";}
			if($rowmethyl["submission_date"] != null)
				{$methylArray[$methylCount] .= "\t".$rowmethyl["submission_date"];}
			else
				{$methylArray[$methylCount] .= "\tNA";}
			if($rowmethyl["GEO_GSM_ID"] != null)
				{$methylArray[$methylCount] .= "\t".$rowmethyl["GEO_GSM_ID"];}
			else
				{$methylArray[$methylCount] .= "\tNA";}
			if($rowmethyl["GEO_GSE_ID"] != null)
				{$methylArray[$methylCount] .= "\t".$rowmethyl["GEO_GSE_ID"];}
			else
				{$methylArray[$methylCount] .= "\tNA";}
			if($rowmethyl["sample_attribute"] != null)
				{$methylArray[$methylCount] .= "\t".$rowmethyl["sample_attribute"];}
			else
				{$methylArray[$methylCount] .= "\tNA";}
			if($rowmethyl["SRA_study_id"] != null)
				{$methylArray[$methylCount] .= "\t".$rowmethyl["SRA_study_id"];}
			else
				{$methylArray[$methylCount] .= "\tNA";}
			
			$methylFileOutput = $rowmethyl[0];
			for($i = 1; $i < count($rowmethyl); $i++)
			{
				$methylFileOutput .= "\t".$rowmethyl[$i];
			}
			fwrite($methylHandle, $methylFileOutput."\n");
			$methylCount++;
		}
	}
	}
	else
	{
	if($tempDataType == "all")
	{
		$sqlRNAseq = "SELECT * FROM EpiDB_rnaseq_track WHERE species_ID='".$tempSpecies."' and tissue_ID='".$tempTissue."' ORDER BY SRA_experiment_id";
		$resultsRNAseq = mysql_query($sqlRNAseq,$connect) or die(mysql_error());
		while($rowRNAseq = mysql_fetch_array($resultsRNAseq))
		{
			$rnaseqArray[$rnaseqCount] = $rowRNAseq["SRA_experiment_id"]."\t".$rowRNAseq["tissue_ID"];
			if($rowRNAseq["study_title"] != null)
				{$rnaseqArray[$rnaseqCount] .= "\t".$rowRNAseq["study_title"];}
			else
				{$rnaseqArray[$rnaseqCount] .= "\tNA";}
			if($rowRNAseq["NumberOfBases"] != null)
				{$rnaseqArray[$rnaseqCount] .= "\t".$rowRNAseq["NumberOfBases"];}
			else
				{$rnaseqArray[$rnaseqCount] .= "\tNA";}
			if($rowRNAseq["library_layout"] != null)
				{$rnaseqArray[$rnaseqCount] .= "\t".$rowRNAseq["library_layout"];}
			else
				{$rnaseqArray[$rnaseqCount] .= "\tNA";}
			if($rowRNAseq["submission_date"] != null)
				{$rnaseqArray[$rnaseqCount] .= "\t".$rowRNAseq["submission_date"];}
			else
				{$rnaseqArray[$rnaseqCount] .= "\tNA";}
			if($rowRNAseq["GEO_GSM_ID"] != null)
				{$rnaseqArray[$rnaseqCount] .= "\t".$rowRNAseq["GEO_GSM_ID"];}
			else
				{$rnaseqArray[$rnaseqCount] .= "\tNA";}
			if($rowRNAseq["GEO_GSE_ID"] != null)
				{$rnaseqArray[$rnaseqCount] .= "\t".$rowRNAseq["GEO_GSE_ID"];}
			else
				{$rnaseqArray[$rnaseqCount] .= "\tNA";}
			if($rowRNAseq["sample_attribute"] != null)
				{$rnaseqArray[$rnaseqCount] .= "\t".$rowRNAseq["sample_attribute"];}
			else
				{$rnaseqArray[$rnaseqCount] .= "\tNA";}
			if($rowRNAseq["SRA_study_id"] != null)
				{$rnaseqArray[$rnaseqCount] .= "\t".$rowRNAseq["SRA_study_id"];}
			else
				{$rnaseqArray[$rnaseqCount] .= "\tNA";}
			
			$rnaseqFileOutput = $rowRNAseq[0];
			for($i = 1; $i < count($rowRNAseq); $i++)
			{
				$rnaseqFileOutput .= "\t".$rowRNAseq[$i];
			}
			fwrite($rnaseqHandle, $rnaseqFileOutput."\n");
			$rnaseqCount++;
		}
		$sqlChIPseq = "SELECT * FROM EpiDB_chipseq_track WHERE species_ID='".$tempSpecies."' and tissue_ID='".$tempTissue."' ORDER BY SRA_experiment_id";
		$resultsChIPseq = mysql_query($sqlChIPseq,$connect) or die(mysql_error());
		while($rowChIPseq = mysql_fetch_array($resultsChIPseq))
		{
			$chipseqArray[$chipseqCount] = $rowChIPseq["SRA_experiment_id"]."\t".$rowChIPseq["tissue_ID"];
			if($rowChIPseq["study_title"] != null)
				{$chipseqArray[$chipseqCount] .= "\t".$rowChIPseq["study_title"];}
			else
				{$chipseqArray[$chipseqCount] .= "\tNA";}
			if($rowChIPseq["NumberOfBases"] != null)
				{$chipseqArray[$chipseqCount] .= "\t".$rowChIPseq["NumberOfBases"];}
			else
				{$chipseqArray[$chipseqCount] .= "\tNA";}
			if($rowChIPseq["library_layout"] != null)
				{$chipseqArray[$chipseqCount] .= "\t".$rowChIPseq["library_layout"];}
			else
				{$chipseqArray[$chipseqCount] .= "\tNA";}
			if($rowChIPseq["submission_date"] != null)
				{$chipseqArray[$chipseqCount] .= "\t".$rowChIPseq["submission_date"];}
			else
				{$chipseqArray[$chipseqCount] .= "\tNA";}
			if($rowChIPseq["GEO_GSM_ID"] != null)
				{$chipseqArray[$chipseqCount] .= "\t".$rowChIPseq["GEO_GSM_ID"];}
			else
				{$chipseqArray[$chipseqCount] .= "\tNA";}
			if($rowChIPseq["GEO_GSE_ID"] != null)
				{$chipseqArray[$chipseqCount] .= "\t".$rowChIPseq["GEO_GSE_ID"];}
			else
				{$chipseqArray[$chipseqCount] .= "\tNA";}
			if($rowChIPseq["sample_attribute"] != null)
				{$chipseqArray[$chipseqCount] .= "\t".$rowChIPseq["sample_attribute"];}
			else
				{$chipseqArray[$chipseqCount] .= "\tNA";}
			if($rowChIPseq["SRA_study_id"] != null)
				{$chipseqArray[$chipseqCount] .= "\t".$rowChIPseq["SRA_study_id"];}
			else
				{$chipseqArray[$chipseqCount] .= "\tNA";}
			
			$chipseqFileOutput = $rowChIPseq[0];
			for($i = 1; $i < count($rowChIPseq); $i++)
			{
				$chipseqFileOutput .= "\t".$rowChIPseq[$i];
			}
			fwrite($chipseqHandle, $chipseqFileOutput."\n");
			$chipseqCount++;
		}
		$sqlmiRNA = "SELECT * FROM EpiDB_miRNA_track WHERE species_ID='".$tempSpecies."' and tissue_ID='".$tempTissue."' ORDER BY SRA_experiment_id";
		$resultsmiRNA = mysql_query($sqlmiRNA,$connect) or die(mysql_error());
		while($rowmiRNA = mysql_fetch_array($resultsmiRNA))
		{
			$mirnaArray[$mirnaCount] = $rowmiRNA["SRA_experiment_id"]."\t".$rowmiRNA["tissue_ID"];
			if($rowmiRNA["study_title"] != null)
				{$mirnaArray[$mirnaCount] .= "\t".$rowmiRNA["study_title"];}
			else
				{$mirnaArray[$mirnaCount] .= "\tNA";}
			if($rowmiRNA["NumberOfBases"] != null)
				{$mirnaArray[$mirnaCount] .= "\t".$rowmiRNA["NumberOfBases"];}
			else
				{$mirnaArray[$mirnaCount] .= "\tNA";}
			if($rowmiRNA["library_layout"] != null)
				{$mirnaArray[$mirnaCount] .= "\t".$rowmiRNA["library_layout"];}
			else
				{$mirnaArray[$mirnaCount] .= "\tNA";}
			if($rowmiRNA["submission_date"] != null)
				{$mirnaArray[$mirnaCount] .= "\t".$rowmiRNA["submission_date"];}
			else
				{$mirnaArray[$mirnaCount] .= "\tNA";}
			if($rowmiRNA["GEO_GSM_ID"] != null)
				{$mirnaArray[$mirnaCount] .= "\t".$rowmiRNA["GEO_GSM_ID"];}
			else
				{$mirnaArray[$mirnaCount] .= "\tNA";}
			if($rowmiRNA["GEO_GSE_ID"] != null)
				{$mirnaArray[$mirnaCount] .= "\t".$rowmiRNA["GEO_GSE_ID"];}
			else
				{$mirnaArray[$mirnaCount] .= "\tNA";}
			if($rowmiRNA["sample_attribute"] != null)
				{$mirnaArray[$mirnaCount] .= "\t".$rowmiRNA["sample_attribute"];}
			else
				{$mirnaArray[$mirnaCount] .= "\tNA";}
			if($rowmiRNA["SRA_study_id"] != null)
				{$mirnaArray[$mirnaCount] .= "\t".$rowmiRNA["SRA_study_id"];}
			else
				{$mirnaArray[$mirnaCount] .= "\tNA";}
			
			$mirnaFileOutput = $rowmiRNA[0];
			for($i = 1; $i < count($rowmiRNA); $i++)
			{
				$mirnaFileOutput .= "\t".$rowmiRNA[$i];
			}
			fwrite($mirnaHandle, $mirnaFileOutput."\n");
			$mirnaCount++;
		}
		$sqlmethyl = "SELECT * FROM EpiDB_Methyl_track WHERE species_ID='".$tempSpecies."' and tissue_ID='".$tempTissue."' ORDER BY SRA_experiment_id";
		$resultsmethyl = mysql_query($sqlmethyl,$connect) or die(mysql_error());
		while($rowmethyl = mysql_fetch_array($resultsmethyl))
		{
			$methylArray[$methylCount] = $rowmethyl["SRA_experiment_id"]."\t".$rowmethyl["tissue_ID"];
			if($rowmethyl["study_title"] != null)
				{$methylArray[$methylCount] .= "\t".$rowmethyl["study_title"];}
			else
				{$methylArray[$methylCount] .= "\tNA";}
			if($rowmethyl["NumberOfBases"] != null)
				{$methylArray[$methylCount] .= "\t".$rowmethyl["NumberOfBases"];}
			else
				{$methylArray[$methylCount] .= "\tNA";}
			if($rowmethyl["library_layout"] != null)
				{$methylArray[$methylCount] .= "\t".$rowmethyl["library_layout"];}
			else
				{$methylArray[$methylCount] .= "\tNA";}
			if($rowmethyl["submission_date"] != null)
				{$methylArray[$methylCount] .= "\t".$rowmethyl["submission_date"];}
			else
				{$methylArray[$methylCount] .= "\tNA";}
			if($rowmethyl["GEO_GSM_ID"] != null)
				{$methylArray[$methylCount] .= "\t".$rowmethyl["GEO_GSM_ID"];}
			else
				{$methylArray[$methylCount] .= "\tNA";}
			if($rowmethyl["GEO_GSE_ID"] != null)
				{$methylArray[$methylCount] .= "\t".$rowmethyl["GEO_GSE_ID"];}
			else
				{$methylArray[$methylCount] .= "\tNA";}
			if($rowmethyl["sample_attribute"] != null)
				{$methylArray[$methylCount] .= "\t".$rowmethyl["sample_attribute"];}
			else
				{$methylArray[$methylCount] .= "\tNA";}
			if($rowmethyl["SRA_study_id"] != null)
				{$methylArray[$methylCount] .= "\t".$rowmethyl["SRA_study_id"];}
			else
				{$methylArray[$methylCount] .= "\tNA";}
			
			$methylFileOutput = $rowmethyl[0];
			for($i = 1; $i < count($rowmethyl); $i++)
			{
				$methylFileOutput .= "\t".$rowmethyl[$i];
			}
			fwrite($methylHandle, $methylFileOutput."\n");
			$methylCount++;
		}
	}
	elseif($tempDataType == "rnaseq")
	{
		$sqlRNAseq = "SELECT * FROM EpiDB_rnaseq_track WHERE species_ID='".$tempSpecies."' and tissue_ID='".$tempTissue."' ORDER BY SRA_experiment_id";
		$resultsRNAseq = mysql_query($sqlRNAseq,$connect) or die(mysql_error());
		while($rowRNAseq = mysql_fetch_array($resultsRNAseq))
		{
			$rnaseqArray[$rnaseqCount] = $rowRNAseq["SRA_experiment_id"]."\t".$rowRNAseq["tissue_ID"];
			if($rowRNAseq["study_title"] != null)
				{$rnaseqArray[$rnaseqCount] .= "\t".$rowRNAseq["study_title"];}
			else
				{$rnaseqArray[$rnaseqCount] .= "\tNA";}
			if($rowRNAseq["NumberOfBases"] != null)
				{$rnaseqArray[$rnaseqCount] .= "\t".$rowRNAseq["NumberOfBases"];}
			else
				{$rnaseqArray[$rnaseqCount] .= "\tNA";}
			if($rowRNAseq["library_layout"] != null)
				{$rnaseqArray[$rnaseqCount] .= "\t".$rowRNAseq["library_layout"];}
			else
				{$rnaseqArray[$rnaseqCount] .= "\tNA";}
			if($rowRNAseq["submission_date"] != null)
				{$rnaseqArray[$rnaseqCount] .= "\t".$rowRNAseq["submission_date"];}
			else
				{$rnaseqArray[$rnaseqCount] .= "\tNA";}
			if($rowRNAseq["GEO_GSM_ID"] != null)
				{$rnaseqArray[$rnaseqCount] .= "\t".$rowRNAseq["GEO_GSM_ID"];}
			else
				{$rnaseqArray[$rnaseqCount] .= "\tNA";}
			if($rowRNAseq["GEO_GSE_ID"] != null)
				{$rnaseqArray[$rnaseqCount] .= "\t".$rowRNAseq["GEO_GSE_ID"];}
			else
				{$rnaseqArray[$rnaseqCount] .= "\tNA";}
			if($rowRNAseq["sample_attribute"] != null)
				{$rnaseqArray[$rnaseqCount] .= "\t".$rowRNAseq["sample_attribute"];}
			else
				{$rnaseqArray[$rnaseqCount] .= "\tNA";}
			if($rowRNAseq["SRA_study_id"] != null)
				{$rnaseqArray[$rnaseqCount] .= "\t".$rowRNAseq["SRA_study_id"];}
			else
				{$rnaseqArray[$rnaseqCount] .= "\tNA";}
			
			$rnaseqFileOutput = $rowRNAseq[0];
			for($i = 1; $i < count($rowRNAseq); $i++)
			{
				$rnaseqFileOutput .= "\t".$rowRNAseq[$i];
			}
			fwrite($rnaseqHandle, $rnaseqFileOutput."\n");
			$rnaseqCount++;
		}
	}
	elseif($tempDataType == "chipseq")
	{
		$sqlChIPseq = "SELECT * FROM EpiDB_chipseq_track WHERE species_ID='".$tempSpecies."' and tissue_ID='".$tempTissue."' ORDER BY SRA_experiment_id";
		$resultsChIPseq = mysql_query($sqlChIPseq,$connect) or die(mysql_error());
		while($rowChIPseq = mysql_fetch_array($resultsChIPseq))
		{
			$chipseqArray[$chipseqCount] = $rowChIPseq["SRA_experiment_id"]."\t".$rowChIPseq["tissue_ID"];
			if($rowChIPseq["study_title"] != null)
				{$chipseqArray[$chipseqCount] .= "\t".$rowChIPseq["study_title"];}
			else
				{$chipseqArray[$chipseqCount] .= "\tNA";}
			if($rowChIPseq["NumberOfBases"] != null)
				{$chipseqArray[$chipseqCount] .= "\t".$rowChIPseq["NumberOfBases"];}
			else
				{$chipseqArray[$chipseqCount] .= "\tNA";}
			if($rowChIPseq["library_layout"] != null)
				{$chipseqArray[$chipseqCount] .= "\t".$rowChIPseq["library_layout"];}
			else
				{$chipseqArray[$chipseqCount] .= "\tNA";}
			if($rowChIPseq["submission_date"] != null)
				{$chipseqArray[$chipseqCount] .= "\t".$rowChIPseq["submission_date"];}
			else
				{$chipseqArray[$chipseqCount] .= "\tNA";}
			if($rowChIPseq["GEO_GSM_ID"] != null)
				{$chipseqArray[$chipseqCount] .= "\t".$rowChIPseq["GEO_GSM_ID"];}
			else
				{$chipseqArray[$chipseqCount] .= "\tNA";}
			if($rowChIPseq["GEO_GSE_ID"] != null)
				{$chipseqArray[$chipseqCount] .= "\t".$rowChIPseq["GEO_GSE_ID"];}
			else
				{$chipseqArray[$chipseqCount] .= "\tNA";}
			if($rowChIPseq["sample_attribute"] != null)
				{$chipseqArray[$chipseqCount] .= "\t".$rowChIPseq["sample_attribute"];}
			else
				{$chipseqArray[$chipseqCount] .= "\tNA";}
			if($rowChIPseq["SRA_study_id"] != null)
				{$chipseqArray[$chipseqCount] .= "\t".$rowChIPseq["SRA_study_id"];}
			else
				{$chipseqArray[$chipseqCount] .= "\tNA";}
			
			$chipseqFileOutput = $rowChIPseq[0];
			for($i = 1; $i < count($rowChIPseq); $i++)
			{
				$chipseqFileOutput .= "\t".$rowChIPseq[$i];
			}
			fwrite($chipseqHandle, $chipseqFileOutput."\n");
			$chipseqCount++;
		}
	}
	elseif($tempDataType == "miRNA")
	{
		$sqlmiRNA = "SELECT * FROM EpiDB_miRNA_track WHERE species_ID='".$tempSpecies."' and tissue_ID='".$tempTissue."' ORDER BY SRA_experiment_id";
		$resultsmiRNA = mysql_query($sqlmiRNA,$connect) or die(mysql_error());
		while($rowmiRNA = mysql_fetch_array($resultsmiRNA))
		{
			$mirnaArray[$mirnaCount] = $rowmiRNA["SRA_experiment_id"]."\t".$rowmiRNA["tissue_ID"];
			if($rowmiRNA["study_title"] != null)
				{$mirnaArray[$mirnaCount] .= "\t".$rowmiRNA["study_title"];}
			else
				{$mirnaArray[$mirnaCount] .= "\tNA";}
			if($rowmiRNA["NumberOfBases"] != null)
				{$mirnaArray[$mirnaCount] .= "\t".$rowmiRNA["NumberOfBases"];}
			else
				{$mirnaArray[$mirnaCount] .= "\tNA";}
			if($rowmiRNA["library_layout"] != null)
				{$mirnaArray[$mirnaCount] .= "\t".$rowmiRNA["library_layout"];}
			else
				{$mirnaArray[$mirnaCount] .= "\tNA";}
			if($rowmiRNA["submission_date"] != null)
				{$mirnaArray[$mirnaCount] .= "\t".$rowmiRNA["submission_date"];}
			else
				{$mirnaArray[$mirnaCount] .= "\tNA";}
			if($rowmiRNA["GEO_GSM_ID"] != null)
				{$mirnaArray[$mirnaCount] .= "\t".$rowmiRNA["GEO_GSM_ID"];}
			else
				{$mirnaArray[$mirnaCount] .= "\tNA";}
			if($rowmiRNA["GEO_GSE_ID"] != null)
				{$mirnaArray[$mirnaCount] .= "\t".$rowmiRNA["GEO_GSE_ID"];}
			else
				{$mirnaArray[$mirnaCount] .= "\tNA";}
			if($rowmiRNA["sample_attribute"] != null)
				{$mirnaArray[$mirnaCount] .= "\t".$rowmiRNA["sample_attribute"];}
			else
				{$mirnaArray[$mirnaCount] .= "\tNA";}
			if($rowmiRNA["SRA_study_id"] != null)
				{$mirnaArray[$mirnaCount] .= "\t".$rowmiRNA["SRA_study_id"];}
			else
				{$mirnaArray[$mirnaCount] .= "\tNA";}
			
			$mirnaFileOutput = $rowmiRNA[0];
			for($i = 1; $i < count($rowmiRNA); $i++)
			{
				$mirnaFileOutput .= "\t".$rowmiRNA[$i];
			}
			fwrite($mirnaHandle, $mirnaFileOutput."\n");
			$mirnaCount++;
		}
	}
	elseif($tempDataType == "methyl")
	{
		$sqlmethyl = "SELECT * FROM EpiDB_Methyl_track WHERE species_ID='".$tempSpecies."' and tissue_ID='".$tempTissue."' ORDER BY SRA_experiment_id";
		$resultsmethyl = mysql_query($sqlmethyl,$connect) or die(mysql_error());
		while($rowmethyl = mysql_fetch_array($resultsmethyl))
		{
			$methylArray[$methylCount] = $rowmethyl["SRA_experiment_id"]."\t".$rowmethyl["tissue_ID"];
			if($rowmethyl["study_title"] != null)
				{$methylArray[$methylCount] .= "\t".$rowmethyl["study_title"];}
			else
				{$methylArray[$methylCount] .= "\tNA";}
			if($rowmethyl["NumberOfBases"] != null)
				{$methylArray[$methylCount] .= "\t".$rowmethyl["NumberOfBases"];}
			else
				{$methylArray[$methylCount] .= "\tNA";}
			if($rowmethyl["library_layout"] != null)
				{$methylArray[$methylCount] .= "\t".$rowmethyl["library_layout"];}
			else
				{$methylArray[$methylCount] .= "\tNA";}
			if($rowmethyl["submission_date"] != null)
				{$methylArray[$methylCount] .= "\t".$rowmethyl["submission_date"];}
			else
				{$methylArray[$methylCount] .= "\tNA";}
			if($rowmethyl["GEO_GSM_ID"] != null)
				{$methylArray[$methylCount] .= "\t".$rowmethyl["GEO_GSM_ID"];}
			else
				{$methylArray[$methylCount] .= "\tNA";}
			if($rowmethyl["GEO_GSE_ID"] != null)
				{$methylArray[$methylCount] .= "\t".$rowmethyl["GEO_GSE_ID"];}
			else
				{$methylArray[$methylCount] .= "\tNA";}
			if($rowmethyl["sample_attribute"] != null)
				{$methylArray[$methylCount] .= "\t".$rowmethyl["sample_attribute"];}
			else
				{$methylArray[$methylCount] .= "\tNA";}
			if($rowmethyl["SRA_study_id"] != null)
				{$methylArray[$methylCount] .= "\t".$rowmethyl["SRA_study_id"];}
			else
				{$methylArray[$methylCount] .= "\tNA";}
			
			$methylFileOutput = $rowmethyl[0];
			for($i = 1; $i < count($rowmethyl); $i++)
			{
				$methylFileOutput .= "\t".$rowmethyl[$i];
			}
			fwrite($methylHandle, $methylFileOutput."\n");
			$methylCount++;
		}
	}
	}
	$resultsCount = count($rnaseqArray) + count($chipseqArray) + count($mirnaArray) + count($methylArray);
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>EpiDB<?php if (isset($title)) {echo "&#8212;{$title}";} ?></title>
<link href="bootstrap.css" rel="stylesheet" type="text/css" />
<link href="bootstrap-responsive.css" rel="stylesheet" type="text/css" />
<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/dropdown.change.js"></script>
<script type="text/javascript">
	$(document).ready(function(){
		$(".tooltip-top").tooltip({
			placement : 'top'
		});
		$(".tooltip-right").tooltip({
			placement : 'right'
		});
		$(".tooltip-bottom").tooltip({
			placement : 'bottom'
		});
		$(".tooltip-left").tooltip({
			placement : 'left'
		});
	});
</script>
</head>

<body>
<?php include('includes/header.inc.php'); ?>
<div class="container">
	<div class="panel panel-primary">
    	<div class="well text-center">
    		<h1>Search</h1>
    	</div>
    	<div class="well">
    		<form class="form-horizontal" action="search.php" method="post" enctype="multipart/form-data" name="searchForm" id="searchForm">
    			<div class="panel"><br/>
    				<div class="form-group row">
    					<h4 class="col-md-2 col-md-offset-1">Species</h4>
    					<select name="species" id="species" class="col-md-offset-1 btn-info">
    						<option value="">Select a species.</option>
            				<?php for($i = 0; $i < count($speciesIDArray); $i++){ ?>
            					<option value="<?php echo $speciesIDArray[$i]; ?>"><?php echo $speciesSNameArray[$i]; ?> (<?php echo $speciesCNameArray[$i]; ?>)</option>
            				<?php } ?>
            			</select>
            		</div>
            	</div>
            	<div class="panel"><br/>
            		<div class="form-group row">
    					<h4 class="col-md-2 col-md-offset-1">'Omics Data Type</h4>
    					<select name="datatype" id="datatype" class="col-md-offset-1 btn-info">
    						<option value="">Select a data type.</option>
            				<option value="all">All</option>
            				<option value="rnaseq">RNA sequence</option>
            				<option value="chipseq">ChIP sequence</option>
            				<option value="miRNA">miRNA sequence</option>
            				<option value="methyl">Methylation sequence</option>
            			</select>
            		</div>
            	</div>
            	<div class="panel"><br/>
            		<div class="form-group row">
    					<h4 class="col-md-2 col-md-offset-1">Tissue</h4>
    					<select name="tissue" id="tissue" class="col-md-offset-1 btn-info">
    						<option value="">Select a tissue.</option>
    						<option value="all">All</option>
            				<?php for($i = 0; $i < count($tissueIDArray); $i++){ ?>
            					<option value="<?php echo $tissueIDArray[$i]; ?>"><?php echo $tissueNameArray[$i]; ?></option>
            				<?php } ?>
            			</select>
            			<?php
            				for($i = 0; $i < count($speciesIDArray); $i++)
            				{
            					echo '<select name="tissue'.$speciesIDArray[$i].'" id="tissue'.$speciesIDArray[$i].'" class="col-md-offset-1 btn-info hidden">';
            					echo '<option value="">Select a tissue.</option>';
            					echo '<option value="all">All</option>';
            					$sqlSpTissue = "SELECT DISTINCT tissue_ID FROM EpiDB_Methyl_track WHERE species_ID='".$speciesIDArray[$i]."'";
            					$sqlSpTissue .= " UNION SELECT DISTINCT tissue_ID FROM EpiDB_chipseq_track WHERE species_ID='".$speciesIDArray[$i]."'";
            					$sqlSpTissue .= " UNION SELECT DISTINCT tissue_ID FROM EpiDB_miRNA_track WHERE species_ID='".$speciesIDArray[$i]."'";
            					$sqlSpTissue .= " UNION SELECT DISTINCT tissue_ID FROM EpiDB_rnaseq_track WHERE species_ID='".$speciesIDArray[$i]."' ORDER BY tissue_ID";
								$resultsSpTissue = mysql_query($sqlSpTissue,$connect) or die(mysql_error());
								while($rowSpTissue = mysql_fetch_array($resultsSpTissue))
								{
									$tempTissue = $rowSpTissue["tissue_ID"];
									$sqlGetTissue = "SELECT tissuetype FROM EpiDB_Tissues WHERE tissue_ID='".$tempTissue."'";
									$resultsGetTissue = mysql_query($sqlGetTissue,$connect) or die(mysql_error());
									while($rowGetTissue = mysql_fetch_array($resultsGetTissue))
									{
										$tempTName = $rowGetTissue["tissuetype"];
										echo '<option value="'.$tempTissue.'">'.$tempTName.'</option>';
									}
								}
								echo '</select>';
								echo '<select name="tissue'.$speciesIDArray[$i].'rnaseq" id="tissue'.$speciesIDArray[$i].'rnaseq" class="col-md-offset-1 btn-info hidden">';
								echo '<option value="">Select a tissue.</option>';
								echo '<option value="all">All</option>';
								$sqlrnaseqTissue = "SELECT DISTINCT tissue_ID FROM EpiDB_rnaseq_track WHERE species_ID='".$speciesIDArray[$i]."' ORDER BY tissue_ID";
								$resultsrnaseqTissue = mysql_query($sqlrnaseqTissue,$connect) or die(mysql_error());
								while($rowrnaseqTissue = mysql_fetch_array($resultsrnaseqTissue))
								{
									$tempTissue = $rowrnaseqTissue["tissue_ID"];
									$sqlGetTissue = "SELECT tissuetype FROM EpiDB_Tissues WHERE tissue_ID='".$tempTissue."'";
									$resultsGetTissue = mysql_query($sqlGetTissue,$connect) or die(mysql_error());
									while($rowGetTissue = mysql_fetch_array($resultsGetTissue))
									{
										$tempTName = $rowGetTissue["tissuetype"];
										echo '<option value="'.$tempTissue.'">'.$tempTName.'</option>';
									}
								}
								echo '</select>';
								echo '<select name="tissue'.$speciesIDArray[$i].'methyl" id="tissue'.$speciesIDArray[$i].'methyl" class="col-md-offset-1 btn-info hidden">';
								echo '<option value="">Select a tissue.</option>';
								echo '<option value="all">All</option>';
								$sqlmethylTissue = "SELECT DISTINCT tissue_ID FROM EpiDB_Methyl_track WHERE species_ID='".$speciesIDArray[$i]."' ORDER BY tissue_ID";
								$resultsmethylTissue = mysql_query($sqlmethylTissue,$connect) or die(mysql_error());
								while($rowmethylTissue = mysql_fetch_array($resultsmethylTissue))
								{
									$tempTissue = $rowmethylTissue["tissue_ID"];
									$sqlGetTissue = "SELECT tissuetype FROM EpiDB_Tissues WHERE tissue_ID='".$tempTissue."'";
									$resultsGetTissue = mysql_query($sqlGetTissue,$connect) or die(mysql_error());
									while($rowGetTissue = mysql_fetch_array($resultsGetTissue))
									{
										$tempTName = $rowGetTissue["tissuetype"];
										echo '<option value="'.$tempTissue.'">'.$tempTName.'</option>';
									}
								}
								echo '</select>';
								echo '<select name="tissue'.$speciesIDArray[$i].'chipseq" id="tissue'.$speciesIDArray[$i].'chipseq" class="col-md-offset-1 btn-info hidden">';
								echo '<option value="">Select a tissue.</option>';
								echo '<option value="all">All</option>';
								$sqlchipseqTissue = "SELECT DISTINCT tissue_ID FROM EpiDB_chipseq_track WHERE species_ID='".$speciesIDArray[$i]."' ORDER BY tissue_ID";
								$resultschipseqTissue = mysql_query($sqlchipseqTissue,$connect) or die(mysql_error());
								while($rowchipseqTissue = mysql_fetch_array($resultschipseqTissue))
								{
									$tempTissue = $rowchipseqTissue["tissue_ID"];
									$sqlGetTissue = "SELECT tissuetype FROM EpiDB_Tissues WHERE tissue_ID='".$tempTissue."'";
									$resultsGetTissue = mysql_query($sqlGetTissue,$connect) or die(mysql_error());
									while($rowGetTissue = mysql_fetch_array($resultsGetTissue))
									{
										$tempTName = $rowGetTissue["tissuetype"];
										echo '<option value="'.$tempTissue.'">'.$tempTName.'</option>';
									}
								}
								echo '</select>';
								echo '<select name="tissue'.$speciesIDArray[$i].'mirna" id="tissue'.$speciesIDArray[$i].'mirna" class="col-md-offset-1 btn-info hidden">';
								echo '<option value="">Select a tissue.</option>';
								echo '<option value="all">All</option>';
								$sqlmirnaTissue = "SELECT DISTINCT tissue_ID FROM EpiDB_miRNA_track WHERE species_ID='".$speciesIDArray[$i]."' ORDER BY tissue_ID";
								$resultsmirnaTissue = mysql_query($sqlmirnaTissue,$connect) or die(mysql_error());
								while($rowmirnaTissue = mysql_fetch_array($resultsmirnaTissue))
								{
									$tempTissue = $rowmirnaTissue["tissue_ID"];
									$sqlGetTissue = "SELECT tissuetype FROM EpiDB_Tissues WHERE tissue_ID='".$tempTissue."'";
									$resultsGetTissue = mysql_query($sqlGetTissue,$connect) or die(mysql_error());
									while($rowGetTissue = mysql_fetch_array($resultsGetTissue))
									{
										$tempTName = $rowGetTissue["tissuetype"];
										echo '<option value="'.$tempTissue.'">'.$tempTName.'</option>';
									}
								}
								echo '</select>';
            				}
            			?>
            		</div>
            	</div>
            	<div class="form-group row">
            		<input class="btn btn-primary col-md-offset-4" type="submit" name="search" id="search" value="Search" />
            	</div>
    		</form>
    	</div>
    	<?php if(array_key_exists('search', $_POST)){ ?>
    		<div class="well">
    			<div class="panel">
    				<h1 class="col-md-offset-1">Results</h1>
    				<h4 class="col-md-offset-1">Your search identified <?php echo $resultsCount; ?> matches.</h4>
    			</div>
    			<?php if(count($rnaseqArray) > 0){ ?>
    				<div class="panel">
    					<h4>RNA Sequence</h4>
    					<table class="table-bordered">
    					<tr>
    						<td class="col-md-1">Experiment</td>
    						<td class="col-md-1">Tissue</td>
    						<td class="col-md-1">Study Title</td>
    						<td class="col-md-1">Number of Bases</td>
    						<td class="col-md-1">Library Layout</td>
    						<td class="col-md-1">Submission Date</td>
    						<td class="col-md-1">Experiment Link</td>
    						<td class="col-md-1">Study Link</td>
    						<td class="col-md-1">Sample Attribute</td>
    						<td class="col-md-1">Study Abstract</td>
    					</tr>
    					<?php for($i = 0; $i < count($rnaseqArray); $i++){
    						$tempSplitRNAseq = explode("\t", $rnaseqArray[$i]); ?>
    						<tr>
    							<td class="text-center"><a target="_blank" href="http://www.ncbi.nlm.nih.gov/sra/<?php echo $tempSplitRNAseq[0]; ?>"><?php echo $tempSplitRNAseq[0]; ?></a></td>
    							<td class="text-center"><?php echo $tissueNameArray[$tempSplitRNAseq[1] - 1]; ?></td>
    							<td class="text-center"><a class="tooltip-bottom" data-toggle="tooltip" title="<?php echo $tempSplitRNAseq[2]; ?>">Title</a></td>
    							<td class="text-center"><?php echo $tempSplitRNAseq[3]; ?></td>
    							<td class="text-center"><?php echo str_replace('- N','',$tempSplitRNAseq[4]); ?></td>
    							<td class="text-center"><?php echo $tempSplitRNAseq[5]; ?></td>
    							<td class="text-center"><?php $tempGSM = explode("_", $tempSplitRNAseq[6]); ?><a target="_blank" href="http://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=<?php echo $tempGSM[0]; ?>"><?php  echo $tempGSM[0]; ?></a></td>
    							<td class="text-center"><a target="_blank" href="http://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=<?php echo $tempSplitRNAseq[7]; ?>"><?php  echo $tempSplitRNAseq[7]; ?></a></td>
    							<td class="text-center"><a class="tooltip-bottom" data-toggle="tooltip" title="<?php echo $tempSplitRNAseq[8]; ?>">Attributes</a></td>
    							<td class="text-center"><a target="_blank" href="http://www.ncbi.nlm.nih.gov/Traces/sra/?study=<?php echo $tempSplitRNAseq[9]; ?>"><?php echo $tempSplitRNAseq[9]; ?></a></td>
    						</tr>
    					<?php } ?>
    					</table><br/>
    					<a href="download.php?currFile=<?php echo $rnaseqFile; ?>" class="btn btn-primary">Download RNAseq Info</a>
    					<h6>Additional experiment and sample level information is available when you download the search results.</h6>
    				</div>
    			<?php } ?>
    			<?php if(count($chipseqArray) > 0){ ?>
    				<div class="panel">
    					<h4>ChIP Sequence</h4>
    					<table class="table-bordered">
    					<tr>
    						<td class="col-md-1">Experiment</td>
    						<td class="col-md-1">Tissue</td>
    						<td class="col-md-1">Study Title</td>
    						<td class="col-md-1">Number of Bases</td>
    						<td class="col-md-1">Library Layout</td>
    						<td class="col-md-1">Submission Date</td>
    						<td class="col-md-1">Experiment Link</td>
    						<td class="col-md-1">Study Link</td>
    						<td class="col-md-1">Sample Attribute</td>
    						<td class="col-md-5">Study Abstract</td>
    					</tr>
    					<?php for($i = 0; $i < count($chipseqArray); $i++){
    						$tempSplitChIPseq = explode("\t", $chipseqArray[$i]); ?>
    						<tr>
    							<td class="text-center"><a target="_blank" href="http://www.ncbi.nlm.nih.gov/sra/<?php echo $tempSplitChIPseq[0]; ?>"><?php  echo $tempSplitChIPseq[0]; ?></a></td>
    							<td class="text-center"><?php echo $tissueNameArray[$tempSplitChIPseq[1] - 1]; ?></td>
    							<td class="text-center"><a class="tooltip-bottom" data-toggle="tooltip" title="<?php echo $tempSplitChIPseq[2]; ?>">Title</a></td>
    							<td class="text-center"><?php echo $tempSplitChIPseq[3]; ?></td>
    							<td class="text-center"><?php echo str_replace('- N','',$tempSplitChIPseq[4]); ?></td>
    							<td class="text-center"><?php echo $tempSplitChIPseq[5]; ?></td>
    							<td class="text-center"><?php $tempGSM = explode("_", $tempSplitChIPseq[6]); ?><a target="_blank" href="http://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=<?php echo $tempGSM[0]; ?>"><?php  echo $tempGSM[0]; ?></a></td>
    							<td class="text-center"><a target="_blank" href="http://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=<?php echo $tempSplitChIPseq[7]; ?>"><?php  echo $tempSplitChIPseq[7]; ?></a></td>
    							<td class="text-center"><a class="tooltip-bottom" data-toggle="tooltip" title="<?php echo $tempSplitChIPseq[8]; ?>">Attributes</a></td>
    							<td class="text-center"><a target="_blank" href="http://www.ncbi.nlm.nih.gov/Traces/sra/?study=<?php echo $tempSplitChIPseq[9]; ?>"><?php  echo $tempSplitChIPseq[9]; ?></a></td>
    						</tr>
    					<?php } ?>
    					</table><br/>
    					<a href="download.php?currFile=<?php echo $chipseqFile; ?>" class="btn btn-primary">Download ChIPseq Info</a>
    					<h6>Additional experiment and sample level information is available when you download the search results.</h6>
    				</div>
    			<?php } ?>
    			<?php if(count($mirnaArray) > 0){ ?>
    				<div class="panel">
    					<h4>miRNA Sequence</h4>
    					<table class="table-bordered">
    					<tr>
    						<td class="col-md-1">Experiment</td>
    						<td class="col-md-1">Tissue</td>
    						<td class="col-md-1">Study Title</td>
    						<td class="col-md-1">Number of Bases</td>
    						<td class="col-md-1">Library Layout</td>
    						<td class="col-md-1">Submission Date</td>
    						<td class="col-md-1">Experiment Link</td>
    						<td class="col-md-1">Study Link</td>
    						<td class="col-md-1">Sample Attribute</td>
    						<td class="col-md-5">Study Abstract</td>
    					</tr>
    					<?php for($i = 0; $i < count($mirnaArray); $i++){
    						$tempSplitmiRNA = explode("\t", $mirnaArray[$i]); ?>
    						<tr>
    							<td class="text-center"><a target="_blank" href="http://www.ncbi.nlm.nih.gov/sra/<?php echo $tempSplitmiRNA[0]; ?>"><?php  echo $tempSplitmiRNA[0]; ?></a></td>
    							<td class="text-center"><?php echo $tissueNameArray[$tempSplitmiRNA[1] - 1]; ?></td>
    							<td class="text-center"><a class="tooltip-bottom" data-toggle="tooltip" title="<?php echo $tempSplitmiRNA[2]; ?>">Title</a></td>
    							<td class="text-center"><?php echo $tempSplitmiRNA[3]; ?></td>
    							<td class="text-center"><?php echo str_replace('- N','',$tempSplitmiRNA[4]); ?></td>
    							<td class="text-center"><?php echo $tempSplitmiRNA[5]; ?></td>
    							<td class="text-center"><?php $tempGSM = explode("_", $tempSplitmiRNA[6]); ?><a target="_blank" href="http://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=<?php echo $tempGSM[0]; ?>"><?php  echo $tempGSM[0]; ?></a></td>
    							<td class="text-center"><a target="_blank" href="http://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=<?php echo $tempSplitmiRNA[7]; ?>"><?php  echo $tempSplitmiRNA[7]; ?></a></td>
    							<td class="text-center"><a class="tooltip-bottom" data-toggle="tooltip" title="<?php echo $tempSplitmiRNA[8]; ?>">Attributes</a></td>
    							<td class="text-center"><a target="_blank" href="http://www.ncbi.nlm.nih.gov/Traces/sra/?study=<?php echo $tempSplitmiRNA[9]; ?>"><?php  echo $tempSplitmiRNA[9]; ?></a></td>
    						</tr>
    					<?php } ?>
    					</table><br/>
    					<a href="download.php?currFile=<?php echo $mirnaFile; ?>" class="btn btn-primary">Download miRNA Info</a>
    					<h6>Additional experiment and sample level information is available when you download the search results.</h6>
    				</div>
    			<?php } ?>
    			<?php if(count($methylArray) > 0){ ?>
    				<div class="panel">
    					<h4>Methylation Sequence</h4>
    					<table class="table-bordered">
    					<tr>
    						<td class="col-md-1">Experiment</td>
    						<td class="col-md-1">Tissue</td>
    						<td class="col-md-1">Study Title</td>
    						<td class="col-md-1">Number of Bases</td>
    						<td class="col-md-1">Library Layout</td>
    						<td class="col-md-1">Submission Date</td>
    						<td class="col-md-1">Experiment Link</td>
    						<td class="col-md-1">Study Link</td>
    						<td class="col-md-1">Sample Attribute</td>
    						<td class="col-md-5">Study Abstract</td>
    					</tr>
    					<?php for($i = 0; $i < count($methylArray); $i++){
    						$tempSplitmethyl = explode("\t", $methylArray[$i]); ?>
    						<tr>
    							<td class="text-center"><a target="_blank" href="http://www.ncbi.nlm.nih.gov/sra/<?php echo $tempSplitmethyl[0]; ?>"><?php  echo $tempSplitmethyl[0]; ?></a></td>
    							<td class="text-center"><?php echo $tissueNameArray[$tempSplitmethyl[1] - 1]; ?></td>
    							<td class="text-center"><a class="tooltip-bottom" data-toggle="tooltip" title="<?php echo $tempSplitmethyl[2]; ?>">Title</a></td>
    							<td class="text-center"><?php echo $tempSplitmethyl[3]; ?></td>
    							<td class="text-center"><?php echo str_replace('- N','',$tempSplitmethyl[4]); ?></td>
    							<td class="text-center"><?php echo $tempSplitmethyl[5]; ?></td>
    							<td class="text-center"><?php $tempGSM = explode("_", $tempSplitmethyl[6]); ?><a target="_blank" href="http://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=<?php echo $tempGSM[0]; ?>"><?php  echo $tempGSM[0]; ?></a></td>
    							<td class="text-center"><a target="_blank" href="http://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=<?php echo $tempSplitmethyl[7]; ?>"><?php  echo $tempSplitmethyl[7]; ?></a></td>
    							<td class="text-center"><a class="tooltip-bottom" data-toggle="tooltip" title="<?php echo $tempSplitmethyl[8]; ?>">Attributes</a></td>
    							<td class="text-center"><a target="_blank" href="http://www.ncbi.nlm.nih.gov/Traces/sra/?study=<?php echo $tempSplitmethyl[9]; ?>"><?php  echo $tempSplitmethyl[9]; ?></a></td>
    						</tr>
    					<?php } ?>
    					</table><br/>
    					<a href="download.php?currFile=<?php echo $methylFile; ?>" class="btn btn-primary">Download Methylation Info</a>
    					<h6>Additional experiment and sample level information is available when you download the search results.</h6>
    				</div>
    			<?php } ?>
    		</div>
    	<?php } ?>
	</div>
</div>
<?php include('includes/footer.inc.php'); ?>
</body>
</html>
<?php mysql_close($connect); ?>