<?php
session_start();
if(!isset($_SESSION['authenticated']))
{
  header('Location: http://www.animalgenome.org/lunney/login.php');
  exit;
}
include('includes/title.inc.php');

if(isset($_SESSION['SearchFile']))
{
	$tempFilename = $_SESSION['SearchFile'];
	$tempPreview = str_replace(".txt", ".preview.txt",$tempFilename);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>PHGC Database<?php if (isset($title)) {echo "&#8212;{$title}";} ?></title>
<link href="bootstrap.css" rel="stylesheet" type="text/css" />
<link href="bootstrap-responsive.css" rel="stylesheet" type="text/css" />
<script src="js/createAjaxObject.js" type="text/javascript" language="javascript"></script>
<script src="js/logincheck.js" type="text/javascript" language="javascript"></script>
<script src="js/jquery.js" type="text/javascript" language="javascript"></script>
<script src="js/bootstrap-alert.js" type="text/javascript" language="javascript"></script>
<script src="js/bootstrap-button/.js" type="text/javascript" language="javascript"></script>
<script src="js/bootstrap-carousel.js" type="text/javascript" language="javascript"></script>
<script src="js/bootstrap-collapse.js" type="text/javascript" language="javascript"></script>
<script src="js/bootstrap-popover.js" type="text/javascript" language="javascript"></script>
<script src="js/bootstrap-scrollspy.js" type="text/javascript" language="javascript"></script>
<script src="js/bootstrap-tab.js" type="text/javascript" language="javascript"></script>
<script src="js/bootstrap-tooltip.js" type="text/javascript" language="javascript"></script>
<script src="js/bootstrap-transition.js" type="text/javascript" language="javascript"></script>
<script src="js/bootstrap-typeahead.js" type="text/javascript" language="javascript"></script>
<script src="js/bootstrap.js" type="text/javascript" language="javascript"></script>
</head>

<body>
<?php include('includes/header.inc.php'); ?>
<div class="container">
	<div class="row">
		<div class="span8 offset2">
			<div class="hero-unit">
    			<h2>Results</h2><br/>
      			<p>Your file containing the information you requested can be downloaded by clicking the link below.</p>
      			<p><a href="#previewFile" role="button" class="btn btn-primary" data-toggle="modal">Preview File</a></p>
      			<div id="previewFile" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  					<div class="modal-header">
    					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">�</button>
    					<h3 id="myModalLabel"><?php echo $tempPreview ?></h3>
  					</div>
  					<div class="modal-body">
    						<?php
								$handle = fopen($tempPreview, "r");
								while($line = fgets($handle, filesize($tempPreview)))
								{
									?> <p> <?php echo $line; ?> </p><?php
								}
								fclose($handle);
    						?>
  					</div>
  					<div class="modal-footer">
    					<button class="btn" data-dismiss="modal" aria-hidden="true">Close</button>
  					</div>
				</div>
      			<p><a href="download.php?currFile=<?php echo $tempFilename; ?>" class="btn btn-primary" >Download File</a></p>
      		</div>
      	</div>
    </div>
</div>
<?php include('includes/footer.inc.php'); ?>
</body>
</html>

<?php
} 
else
{
	header('Location: http://www.animalgenome.org/lunney/login.php');
	exit;
}
?>