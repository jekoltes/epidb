<?php
session_start();

include('includes/title.inc.php');

$connect = mysql_connect('localhost:/data/mysql/mysql.sock', "eric", "R1ftw4lker");
mysql_select_db("EpiDB");

$speciesSNameArray = array();
$speciesCNameArray = array();
$speciesIDArray = array();
$tissueNameArray = array();
$tissueIDArray = array();
$speciesCount = 0;
$tissueCount = 0;

$sqlSpecies = "SELECT * FROM EpiDB_Species";
$resultsSpecies = mysql_query($sqlSpecies,$connect) or die(mysql_error());
while($rowSpecies = mysql_fetch_array($resultsSpecies))
{
	$speciesIDArray[$speciesCount] = $rowSpecies['species_ID'];
	$speciesSNameArray[$speciesCount] = $rowSpecies['species_sname'];
	$speciesCNameArray[$speciesCount] = $rowSpecies['species_cname'];
	$speciesCount++;
}
	
$sqlTissue = "SELECT * from EpiDB_Tissues";
$resultsTissue = mysql_query($sqlTissue,$connect) or die(mysql_error());
while($rowTissue = mysql_fetch_array($resultsTissue))
{
	$tissueNameArray[$tissueCount] = $rowTissue['tissuetype'];
	$tissueIDArray[$tissueCount] = $rowTissue['tissue_ID'];
	$tissueCount++;
}

if(array_key_exists('search', $_POST))
{
	$tempSpecies = $_POST['species'];
	$tempTissue = $_POST['tissue'];
	
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>EpiDB<?php if (isset($title)) {echo "&#8212;{$title}";} ?></title>
<link href="bootstrap.css" rel="stylesheet" type="text/css" />
<link href="bootstrap-responsive.css" rel="stylesheet" type="text/css" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<?php if(array_key_exists('search', $_POST)){ ?>
<script type="text/javascript">
$(function () {
    $('#tissuegraph').highcharts({
        chart: {
            type: 'column'
        },
        title: {
            text: 'Monthly Average Rainfall'
        },
        subtitle: {
            text: 'Source: WorldClimate.com'
        },
        xAxis: {
            categories: [
                'Jan',
                'Feb',
                'Mar',
                'Apr',
                'May',
                'Jun',
                'Jul',
                'Aug',
                'Sep',
                'Oct',
                'Nov',
                'Dec'
            ],
            crosshair: true
        },
        yAxis: {
            min: 0,
            title: {
                text: 'Rainfall (mm)'
            }
        },
        tooltip: {
            headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
            pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
                '<td style="padding:0"><b>{point.y:.1f} mm</b></td></tr>',
            footerFormat: '</table>',
            shared: true,
            useHTML: true
        },
        plotOptions: {
            column: {
                pointPadding: 0.2,
                borderWidth: 0
            }
        },
        series: [{
            name: 'Tokyo',
            data: [49.9, 71.5, 106.4, 129.2, 144.0, 176.0, 135.6, 148.5, 216.4, 194.1, 95.6, 54.4]

        }, {
            name: 'New York',
            data: [83.6, 78.8, 98.5, 93.4, 106.0, 84.5, 105.0, 104.3, 91.2, 83.5, 106.6, 92.3]

        }, {
            name: 'London',
            data: [48.9, 38.8, 39.3, 41.4, 47.0, 48.3, 59.0, 59.6, 52.4, 65.2, 59.3, 51.2]

        }, {
            name: 'Berlin',
            data: [42.4, 33.2, 34.5, 39.7, 52.6, 75.5, 57.4, 60.4, 47.6, 39.1, 46.8, 51.1]

        }]
    });
});
</script>
<?php } ?>
</head>

<body>
<?php include('includes/header.inc.php'); ?>
<script src="js/highcharts.js"></script>
<script src="js/modules/exporting.js"></script>
<div class="container">
	<div class="panel panel-primary">
    	<div class="well text-center">
    		<h1>Gene Expression</h1>
    	</div>
    	<div class="well">
    		<form class="form-horizontal" action="tissue_expression.php" method="post" enctype="multipart/form-data" name="searchForm" id="searchForm">
    			<div class="panel"><br/>
    				<div class="form-group row">
    					<select name="species" class="col-md-offset-1 btn-info">
    						<option value="">Species.</option>
            				<?php for($i = 0; $i < count($speciesIDArray); $i++){ ?>
            					<option value="<?php echo $speciesIDArray[$i]; ?>"><?php echo $speciesSNameArray[$i]; ?> (<?php echo $speciesCNameArray[$i]; ?>)</option>
            				<?php } ?>
            			</select>
            			<select name="tissue" class="col-md-offset-1 btn-info">
    						<option value="">Tissue.</option>
            				<?php for($i = 0; $i < count($tissueIDArray); $i++){ ?>
            					<option value="<?php echo $tissueIDArray[$i]; ?>"><?php echo $tissueNameArray[$i]; ?></option>
            				<?php } ?>
            			</select>
            		</div>
            		<div class="form-group row">
            			<input class="btn btn-primary col-md-offset-4" type="submit" name="search" id="search" value="Get Expression" />
            		</div>
            	</div>
            </form>
        </div>
        <?php if(array_key_exists('search', $_POST)){ ?>
        	<div class="well">
        		<div id="tissuegraph" style="min-width: 310px; height: 1000px; margin: 0 auto"></div>
        	</div>
        <?php } ?>
	</div>
</div>
<?php include('includes/footer.inc.php'); ?>
</body>
</html>
<?php mysql_close($connect); ?>