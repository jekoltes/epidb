<?php
session_start();

include('includes/title.inc.php');

$connect = mysql_connect('localhost:/data/mysql/mysql.sock', "eric", "R1ftw4lker");
mysql_select_db("EpiDB");

$speciesSNameArray = array();
$speciesCNameArray = array();
$tissueNameArray = array();
$speciesCount = 0;
$tissueCount = 0;
$species = "Temp";
$tissue = "Temp";
$tissueFile = "tissue.example.file.txt";
$geneArray = "";
$expressionArray = "";
$firstCount = 0;

$sqlSpecies = "SELECT * FROM EpiDB_Species";
$resultsSpecies = mysql_query($sqlSpecies,$connect) or die(mysql_error());
while($rowSpecies = mysql_fetch_array($resultsSpecies))
{
	$speciesSNameArray[$speciesCount] = $rowSpecies['species_sname'];
	$speciesCNameArray[$speciesCount] = $rowSpecies['species_cname'];
	$speciesCount++;
}
	
$sqlTissue = "SELECT * from EpiDB_Tissues";
$resultsTissue = mysql_query($sqlTissue,$connect) or die(mysql_error());
while($rowTissue = mysql_fetch_array($resultsTissue))
{
	$tissueNameArray[$tissueCount] = $rowTissue['tissuetype'];
	$tissueCount++;
}

if(array_key_exists('search', $_POST))
{
	$species = $_POST['species'];
	$tissue = $_POST['tissue'];
	
}


$txt_file    = file_get_contents($tissueFile);
$rows        = explode("\n", $txt_file);
array_shift($rows);
foreach($rows as $row)
{
	$parts = explode("\t", $row);
	if($firstCount == 0)
	{
		$geneArray = $parts[0];
		$expressionArray = $parts[1];
		$firstCount++;
	}
	else
	{
		$geneArray .= "','".$parts[0];
		$expressionArray .= ",".$parts[1];
	}
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>EpiDB<?php if (isset($title)) {echo "&#8212;{$title}";} ?></title>
<link href="bootstrap.css" rel="stylesheet" type="text/css" />
<link href="bootstrap-responsive.css" rel="stylesheet" type="text/css" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<?php if(array_key_exists('search', $_POST)){ ?>
<script type="text/javascript">
$(function () {
    $('#tissuegraph').highcharts({
        chart: {
            type: 'bar'
        },
        title: {
            text: '<?php echo $species; ?> <?php echo $tissue; ?> Expression'
        },
        subtitle: {
            text: ''
        },
        xAxis: {
            categories: ['<?php echo $geneArray; ?>'],
            title: {
                text: 'Genes'
            }
        },
        yAxis: {
            min: 0,
            title: {
                text: 'Expression (TPM)',
                align: 'high'
            },
            labels: {
                overflow: 'justify'
            }
        },
        tooltip: {
            valueSuffix: ' TPM'
        },
        plotOptions: {
            bar: {
                dataLabels: {
                    enabled: true
                }
            }
        },
        legend: {
            layout: 'vertical',
            align: 'right',
            verticalAlign: 'top',
            x: -40,
            y: 100,
            floating: true,
            borderWidth: 1,
            backgroundColor: ((Highcharts.theme && Highcharts.theme.legendBackgroundColor) || '#FFFFFF'),
            shadow: true
        },
        credits: {
            enabled: false
        },
        series: [{
            name: 'Expression',
            data: [<?php echo $expressionArray; ?>]
        }]
    });
});
</script>
<?php } ?>
</head>

<body>
<?php include('includes/header.inc.php'); ?>
<script src="js/highcharts.js"></script>
<script src="js/modules/exporting.js"></script>
<div class="container">
	<div class="panel panel-primary">
    	<div class="well text-center">
    		<h1>Gene Expression</h1>
    	</div>
    	<div class="well">
    		<form class="form-horizontal" action="gene_expression.php" method="post" enctype="multipart/form-data" name="searchForm" id="searchForm">
    			<div class="panel"><br/>
    				<div class="form-group row">
    					<select name="species" class="col-md-offset-1 btn-info">
    						<option value="">Species.</option>
            				<?php for($i = 0; $i < count($speciesSNameArray); $i++){ ?>
            					<option value="<?php echo $speciesSNameArray[$i]; ?>"><?php echo $speciesSNameArray[$i]; ?> (<?php echo $speciesCNameArray[$i]; ?>)</option>
            				<?php } ?>
            			</select>
            			<select name="tissue" class="col-md-offset-1 btn-info">
    						<option value="">Tissue.</option>
            				<?php for($i = 0; $i < count($tissueNameArray); $i++){ ?>
            					<option value="<?php echo $tissueNameArray[$i]; ?>"><?php echo $tissueNameArray[$i]; ?></option>
            				<?php } ?>
            			</select>
            		</div>
            		<div class="form-group row">
            			<input class="btn btn-primary col-md-offset-4" type="submit" name="search" id="search" value="Get Expression" />
            		</div>
            	</div>
            </form>
        </div>
        <?php if(array_key_exists('search', $_POST)){ ?>
        	<div class="well">
        		<div id="tissuegraph" style="min-width: 310px; height: 500000px; margin: 0 auto"></div>
        	</div>
        <?php } ?>
	</div>
</div>
<?php include('includes/footer.inc.php'); ?>
</body>
</html>
<?php mysql_close($connect); ?>