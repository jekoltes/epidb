#!/usr/bin/perl

use warnings;
use strict;
use DBI;
use DateTime;
use DateTime::Format::MySQL;
 
my $db2 ="isubeefdb";
my $user = "eric";
my $pass = "R1ftw4lker";
my $host="localhost";
my $dbh2 = DBI->connect("DBI:mysql:database=$db2;host=$host;mysql_socket=/data/mysql/mysql.sock",$user,$pass);


	my $animalID = "";
	my $sireID = "";
	my $damID = "";
	my $iquery1 =  "SELECT AnimalID, SireID, DamID Pedigree WHERE ISU='Y'";
	my $isth1 = $dbh2->prepare($iquery1);
	$isth1->execute();
	$isth1->bind_columns(\$animalID,\$sireID,\$damID);
	while($isth1->fetch())
	{
		print $animalID."\t".$sireID."\t".$damID."\n";
	}
}

