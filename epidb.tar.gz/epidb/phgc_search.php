<?php
session_start();
if(!isset($_SESSION['authenticated']))
{
  header('Location: http://www.animalgenome.org/lunney/login.php');
  exit;
}
include('includes/title.inc.php');
$connect = mysql_connect('localhost','eric','LushPed07');
mysql_select_db("host_lunneylab2", $connect);
include('includes/trial_get.inc.php');
include('includes/phenotype_get.inc.php');

if(array_key_exists('updateSearch', $_POST))
{
	$trial_list = $_POST['trial_checkbox'];
	$phenotype_list = $_POST['phenotype_checkbox'];
	$filter_list = $_POST['filter_checkbox'];
	$filterArray = array();
	
	if(in_array("all", $trial_list))
	{
		$phgcArray = $trialarray;
	}
	else
	{
		foreach($trial_list as $tempT)
		{
			$sqltempT = "SELECT Trial_ID, TrialName FROM Trial WHERE Trial_ID='".$tempT."'";
			$querytempT = mysql_query($sqltempT, $connect) or die(mysql_error());
  			while($row = mysql_fetch_assoc($querytempT))
  			{
    			extract($row);
    			$trialid = $row["Trial_ID"];
    			$trialname = $row["TrialName"];
    			$tmptrial = array($trialid, $trialname);
    			$phgcArray[] = $tmptrial;
    		}
		}
	}
	
	if(in_array("all", $phenotype_list))
	{
		$phenoListArray = $phenotypearray;
		$pedigreeCheck = "pedigree";
	}
	else
	{
		foreach($phenotype_list as $tempP)
		{
			if(!($tempP == "pedigree"))
			{
				$sqltempP = "SELECT PhenoID, Name FROM Phenotypes WHERE PhenoID='".$tempP."'";
				$querytempP = mysql_query($sqltempP, $connect) or die(mysql_error());
  				while($row = mysql_fetch_assoc($querytempP))
  				{
    				extract($row);
    				$phenotypeid = $row["PhenoID"];
    				$phenotypename = $row["Name"];
    				$tmpphenotype = array($phenotypeid, $phenotypename);
    				$phenoListArray[] = $tmpphenotype;
    			}
    		}
    		else
    		{
    			$pedigreeCheck = "pedigree";
    		}
		}
	}
	
	if(!(in_array("none", $filter_list)))
	{
		foreach($filter_list as $tempF)
		{
			$tempR = "";
			$sqlRange = "SELECT Continuous FROM Phenotypes WHERE PhenoID='".$tempF."'";
            $queryRange = mysql_query($sqlRange, $connect) or die(mysql_error());
            while($row = mysql_fetch_assoc($queryRange))
            {
            	extract($row);
            	$tempR = $row["Continuous"];
            }
            if($tempR == "0")
            {
				$sqltempF = "SELECT Name FROM Phenotypes WHERE PhenoID='".$tempF."'";
				$querytempF = mysql_query($sqltempF, $connect) or die(mysql_error());
				$tempFName = "";
				while($row = mysql_fetch_assoc($querytempF))
				{
					extract($row);
					$tempFName = $row["Name"];
				}
				$tempFName = str_replace(" ","_",$tempFName);
				$tempFValue = $_POST[$tempFName];
				if($tempFValue == "all")
				{
					$tempUPNArray = array();
					$sqlgetUPN = "SELECT UPN FROM PhenotypeData WHERE PhenoID='".$tempF."'";
					$querygetUPN = mysql_query($sqlgetUPN, $connect) or die(mysql_error());
					while($row = mysql_fetch_assoc($querygetUPN))
					{
						extract($row);
						$tempUPNArray[] = $row["UPN"];
					}
					$filterArray[] = $tempUPNArray;
				}
				else
				{	
					$tempUPNArray = array();
					$sqlgetUPN = "SELECT UPN FROM PhenotypeData WHERE PhenoID='".$tempF."' AND Value='".$tempFValue."'";
					$querygetUPN = mysql_query($sqlgetUPN, $connect) or die(mysql_error());
					while($row = mysql_fetch_assoc($querygetUPN))
					{
						extract($row);
						$tempUPNArray[] = $row["UPN"];
					}
					$filterArray[] = $tempUPNArray;
				}
			}
			else
			{
				$sqltempF = "SELECT Name FROM Phenotypes WHERE PhenoID='".$tempF."'";
				$querytempF = mysql_query($sqltempF, $connect) or die(mysql_error());
				$tempFName = "";
				while($row = mysql_fetch_assoc($querytempF))
				{
					extract($row);
					$tempFName = $row["Name"];
				}
				$tempFName = str_replace(" ","_",$tempFName);
				$tempFValue = $_POST[$tempFName];
				$rangeSplit = split('-',$tempFValue);
				$tempUPNArray = array();
				$sqlgetUPN = "SELECT UPN FROM PhenotypeData WHERE PhenoID='".$tempF."' AND Value > '".$rangeSplit[0]."' AND Value <= '".$rangeSplit[1]."'";
				$querygetUPN = mysql_query($sqlgetUPN, $connect) or die(mysql_error());
				while($row = mysql_fetch_assoc($querygetUPN))
				{
					extract($row);
					$tempUPNArray[] = $row["UPN"];
				}
				$filterArray[] = $tempUPNArray;
			}
		}
	}
}
else
{
	$phgcArray = $trialarray;
  	$phenoListArray = $phenotypearray;
  	$pedigreeCheck = "pedigree";
}

$TV = time();
$genotypeFile = '/tmp/genotypeUPN.'.$TV.'.txt';
$genotypeOutput = '/tmp/genotypeOutput.'.$TV.'.txt';
$genotypeHandle = fopen($genotypeFile, 'w') or die('Cannot open file: '.$genotypeFile);
      	 									
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>PHGC Database<?php if (isset($title)) {echo "&#8212;{$title}";} ?></title>
<link href="bootstrap.css" rel="stylesheet" type="text/css" />
<link href="bootstrap-responsive.css" rel="stylesheet" type="text/css" />
<script src="js/createAjaxObject.js" type="text/javascript" language="javascript"></script>
<script src="js/logincheck.js" type="text/javascript" language="javascript"></script>
<script src="js/jquery.js" type="text/javascript" language="javascript"></script>
<script src="js/bootstrap-alert.js" type="text/javascript" language="javascript"></script>
<script src="js/bootstrap-button/.js" type="text/javascript" language="javascript"></script>
<script src="js/bootstrap-carousel.js" type="text/javascript" language="javascript"></script>
<script src="js/bootstrap-collapse.js" type="text/javascript" language="javascript"></script>
<script src="js/bootstrap-popover.js" type="text/javascript" language="javascript"></script>
<script src="js/bootstrap-scrollspy.js" type="text/javascript" language="javascript"></script>
<script src="js/bootstrap-tab.js" type="text/javascript" language="javascript"></script>
<script src="js/bootstrap-tooltip.js" type="text/javascript" language="javascript"></script>
<script src="js/bootstrap-transition.js" type="text/javascript" language="javascript"></script>
<script src="js/bootstrap-typeahead.js" type="text/javascript" language="javascript"></script>
<script src="js/bootstrap.js" type="text/javascript" language="javascript"></script>
</head>

<body>
<?php include('includes/header.inc.php'); ?>
<div class="container">
	<div class="panel panel-primary">
		<form class="form-horizontal" action="phgc_search.php" method="post" enctype="multipart/form-data" name="searchForm" id="searchForm">
    		<div class="well">
    			<h2>Trials:</h2>
    			<ul class="list-inline">
  					<li><input type="checkbox" name="trial_checkbox[]" value="all" <?php if(!array_key_exists('updateSearch', $_POST)){echo "checked";}elseif(array_key_exists('updateSearch', $_POST) && in_array("all", $trial_list)){echo "checked";} ?>>All</li>
              		<?php
                		for($j = 0; $j < count($trialarray); $j++)
                		{
                  			$trialid = $trialarray[$j][0];
                  			$trialname = $trialarray[$j][1];
                  			echo '<li><input type="checkbox" name="trial_checkbox[]" value="'.$trialid.'"';
                  			if(array_key_exists('updateSearch', $_POST) && !(in_array("all", $trial_list)) && in_array($trialid, $trial_list)){echo " checked";}
                  			echo '>'.$trialname."</li>";  
                		}
              		?>
              	</ul>
            </div>
            <div class="well">
              	<h2>Phenotypes:</h2>
              	<ul class="list-inline">
            		<li><input type="checkbox" name="phenotype_checkbox[]" value="all" <?php if(!array_key_exists('updateSearch', $_POST)){echo "checked";}elseif(array_key_exists('updateSearch', $_POST) && in_array("all", $phenotype_list)){echo "checked";} ?>>All</li>
            		<li><input type="checkbox" name="phenotype_checkbox[]" value="pedigree" <?php if(array_key_exists('updateSearch', $_POST) && !(in_array("all", $phenotype_list)) && in_array("pedigree", $phenotype_list)){echo "checked";} ?>>Pedigree</li>
            		<?php
            			for($k = 0; $k < count($phenotypearray); $k++)
            			{
            				$phenotypeid = $phenotypearray[$k][0];
            				$phenotypename = $phenotypearray[$k][1];
            				echo '<li> <input type="checkbox" name="phenotype_checkbox[]" value="'.$phenotypeid.'"';
            				if(array_key_exists('updateSearch', $_POST) && !(in_array("all", $phenotype_list)) && in_array($phenotypeid, $phenotype_list)){echo " checked";}
            				echo '>'.$phenotypename.'</li>';
            			}
            		?>
            	</ul>
            </div>
            <div class="well">
            	<h2>Filters:</h2>
            	<div class="control-group">
            		<div class="row"><div class="col-md-3"><input type="checkbox" name="filter_checkbox[]" value="none" <?php if(!array_key_exists('updateSearch', $_POST)){echo "checked";}elseif(array_key_exists('updateSearch', $_POST) && in_array("none", $filter_list)){echo "checked";} ?>>None</div></div>
            		<?php
            			for($k = 0; $k < count($phenotypearray); $k++)
            			{
            				$filterid = $phenotypearray[$k][0];
            				$filtername = $phenotypearray[$k][1];
            				echo '<div class="row"><div class="col-md-3"><input type="checkbox" name="filter_checkbox[]" value="'.$filterid.'"';
            				if(array_key_exists('updateSearch', $_POST) && !(in_array("none", $filter_list)) && in_array($filterid, $filter_list)){echo " checked";}
            				echo '>'.$filtername.'</div>';
            				$nameTemp = str_replace(" ","_",$filtername);
            				$tempC = "";
            				$sqlContinuous = "SELECT Continuous FROM Phenotypes WHERE PhenoID='".$filterid."'";
            				$queryContinuous = mysql_query($sqlContinuous, $connect) or die(mysql_error());
            				while($row = mysql_fetch_assoc($queryContinuous))
            				{
            					extract($row);
            					$tempC = $row["Continuous"];
            				}
            				if($tempC == "0")
            				{
            					echo '<select name="'.$nameTemp.'"><option value="">Select a value.</option>';
            					echo '<option value="all"';
            					if($_POST[$nameTemp] && !(in_array("none", $filter_list)))
            					{
            						if($_POST[$nameTemp] == "all")
            							{echo ' selected';}
            					}
            					echo '>All</option>';
            					$sqlfilter = "SELECT Value FROM PhenotypeData WHERE PhenoID='".$filterid."' GROUP BY Value";
            					$queryfilter = mysql_query($sqlfilter, $connect) or die(mysql_error());
            					while($row = mysql_fetch_assoc($queryfilter))
            					{
            						extract($row);
            						$tempValue = $row["Value"];
            						echo '<option value="'.$tempValue.'"';
            						if($_POST[$nameTemp] && !(in_array("none", $filter_list)))
            						{
            							if($_POST[$nameTemp] == $tempValue)
            								{echo ' selected';}
            						}
            						echo '>'.$tempValue.'</option>';
            					}
            					echo '</select></div>';
            				}
            				else
            				{
            					echo '<select name="'.$nameTemp.'"><option value="">Select a value.</option>';
            					$sqlMax = "SELECT Value FROM PhenotypeData WHERE PhenoID='".$filterid."'";
            					$queryMax = mysql_query($sqlMax, $connect) or die(mysql_error());
            					$resultMax = 0;
            					while($row = mysql_fetch_assoc($queryMax))
            					{
            						extract($row);
            						if($row["Value"] > $resultMax)
            							{$resultMax = $row["Value"];}
            					}
            					$additionFactor = intval($resultMax/5);
            					$range1 = '0-'.$additionFactor;
            					$range2 = ($additionFactor+1).'-'.($additionFactor*2);
            					$range3 = (($additionFactor*2)+1).'-'.($additionFactor*3);
            					$range4 = (($additionFactor*3)+1).'-'.($additionFactor*4);
            					$range5 = (($additionFactor*4)+1).'-'.$resultMax;
            					echo '<option value="'.$range1.'"';
            					if($_POST[$nameTemp] && !(in_array("none", $filter_list)))
            					{
            						if($_POST[$nameTemp] == $range1)
            							{echo ' selected';}
            					}
            					echo '>'.$range1.'</option>';
            					echo '<option value="'.$range2.'"';
            					if($_POST[$nameTemp] && !(in_array("none", $filter_list)))
            					{
            						if($_POST[$nameTemp] == $range2)
            							{echo ' selected';}
            					}
            					echo '>'.$range2.'</option>';
            					echo '<option value="'.$range3.'"';
            					if($_POST[$nameTemp] && !(in_array("none", $filter_list)))
            					{
            						if($_POST[$nameTemp] == $range3)
            							{echo ' selected';}
            					}
            					echo '>'.$range3.'</option>';
            					echo '<option value="'.$range4.'"';
            					if($_POST[$nameTemp] && !(in_array("none", $filter_list)))
            					{
            						if($_POST[$nameTemp] == $range4)
            							{echo ' selected';}
            					}
            					echo '>'.$range4.'</option>';
            					echo '<option value="'.$range5.'"';
            					if($_POST[$nameTemp] && !(in_array("none", $filter_list)))
            					{
            						if($_POST[$nameTemp] == $range5)
            							{echo ' selected';}
            					}
            					echo '>'.$range5.'</option>';
            					echo '</select></div>';
            				}
            			}
            		?>
            	</div>
            </div>
            <div class="well">
            	<input class="btn btn-primary" type="submit" name="updateSearch" id="updateSearch" value="Update" />
            </div>
        </form>
    	<div class="well">
    		<h2>Results:</h2>
    		<?php if(array_key_exists('updateSearch', $_POST)){ ?>
    		<form action="genotype_search.php" method="post" enctype="multipart/form-data">
    				<input type="hidden" name="upnFile" value="<?php echo $genotypeFile; ?>" />
    				<input type="hidden" name="outputFile" value="<?php echo $genotypeOutput; ?>" />
    				<select name="formatType">
    					<option value="">Select a format.</option>
    					<option value="gensel">Gensel</option>
    					<option value="tabbed">Excel</option>
    				</select>
    				<input class="btn" type="submit" name="genotypeSearch" id="genotypeSearch" value="Get Genotypes" />
    			</form><br/>
    			<div class="row">
    		<?php
    			for($p = 0; $p < count($phgcArray); $p++)
    			{
    				$tempPHGC = str_replace(" ","_",$phgcArray[$p][1]);
    				$phgcTrialFile = '/tmp/PHGCSearch.'.$tempPHGC."-".$TV.'.txt';
    				$phgcTrialHandle = fopen($phgcTrialFile,w) or die('Cannot open file: '.$phgcTrialFile);
    				?>
    				<a href="download.php?currFile=<?php echo $phgcTrialFile; ?>" class="btn btn-primary">Download <?php echo $tempPHGC; ?></a>
    				<?php
    				$UPNList = array();
    				$sqlUPNList = "SELECT UPN FROM Pedigree WHERE Trial_ID='".$phgcArray[$p][0]."' ORDER BY UPN";
    				$queryUPNList = mysql_query($sqlUPNList, $connect) or die(mysql_error());
    				while($row = mysql_fetch_assoc($queryUPNList))
    				{
    					extract($row);
    					$UPNList[] = $row["UPN"];
    				}
    				if($pedigreeCheck == "pedigree")
    				{
    					$sqlAllPedHeader = "DESCRIBE Pedigree";
    					$queryAllPedHeader = mysql_query($sqlAllPedHeader,$connect) or die(mysql_error());
    					while($row = mysql_fetch_assoc($queryAllPedHeader))
    					{
    						extract($row);
    						fwrite($phgcTrialHandle, $row["Field"]."\t");
    					}
    				}
    				for($u = 0; $u < count($phenoListArray); $u++)
    				{
    					$tempPheno = str_replace(" ","_",$phenoListArray[$u][1]);
    					$sqlPhenoDates = "SELECT Date FROM PhenotypeData WHERE UPN='".$UPNList[0]."'";
    					$queryPhenoDates = mysql_query($sqlPhenoDates, $connect) or die(mysql_error());
    					while($row = mysql_fetch_assoc($queryPhenoDates))
    					{
    						extract($row);
    						fwrite($phgcTrialHandle,$tempPheno."_".$row["Date"]."\t");
    					}
    				}
    				fwrite($phgcTrialHandle,"\n");
    				
    				for($r = 0; $r < count($UPNList);$r++)
    				{
    					if(in_array("none",$filter_list))
    					{
    						if($pedigreeCheck == "pedigree")
    						{
    							$sqlPedigreeAll = "SELECT * FROM Pedigree WHERE UPN='".$UPNList[$r]."'";
    							$queryPedigreeAll = mysql_query($sqlPedigreeAll, $connect) or die(mysql_error());
    							while($row = mysql_fetch_assoc($queryPedigreeAll))
    							{
    								extract($row);
    								fwrite($phgcTrialHandle, $row["UPN"]."\t");
    								fwrite($phgcTrialHandle, $row["BirthDate"]."\t");
    								fwrite($phgcTrialHandle, $row["Gender"]."\t");
    								fwrite($phgcTrialHandle, $row["Sire"]."\t");
    								fwrite($phgcTrialHandle, $row["Dam"]."\t");
    								fwrite($phgcTrialHandle, $row["HarvestDate"]."\t");
    								$sqlGetTrial = "SELECT TrialName FROM Trial WHERE Trial_ID='".$row["Trial_ID"]."'";
    								$queryGetTrial = mysql_query($sqlGetTrial, $connect) or die(mysql_error());
    								while($row2 = mysql_fetch_assoc($queryGetTrial))
    								{
    									extract($row2);
    									fwrite($phgcTrialHandle,$row2["TrialName"]."\t");
    								}
    								fwrite($phgcTrialHandle, $row["ProviderPig_ID"]."\t");
    								fwrite($phgcTrialHandle, $row["ExperimentPig_ID"]."\t");
    								fwrite($phgcTrialHandle, $row["PenNumber"]."\t");
    								fwrite($phgcTrialHandle, $row["Litter_ID"]."\t");
    								fwrite($phgcTrialHandle, $row["Farm_ID"]."\t");
    							}
    						}
    						else
    						{
    							fwrite($phgcTrialHandle, $UPNList[$r]."\t");
    						}
    						for($q = 0; $q < count($phenoListArray); $q++)
    						{
    							$sqlPhenoAll = "SELECT * FROM PhenotypeData WHERE PhenoID='".$phenoListArray[$q][0]."' AND UPN='".$UPNList[$r]."'";
    							$queryPhenoAll = mysql_query($sqlPhenoAll, $connect) or die(mysql_error());
    							while($row = mysql_fetch_assoc($queryPhenoAll))
    							{
    								extract($row);
    								fwrite($phgcTrialHandle, $row["Value"]);
    								if($row["Units_ID"] > 0)
    								{
    									$sqlPhenoAllUnits = "SELECT Unit_Type FROM Units WHERE Units_ID='".$row["Units_ID"]."'";
    									$queryPhenoAllUnits = mysql_query($sqlPhenoAllUnits, $connect) or die(mysql_error());
    									while($row2 = mysql_fetch_assoc($queryPhenoAllUnits))
    									{
    										extract($row2);
    										fwrite($phgcTrialHandle, " ".$row2["Unit_Type"]."\t");
    									}
    								}
    								else
    								{
    									fwrite($phgcTrialHandle, "\t");
    								}
    							}
    						}
    						fwrite($phgcTrialHandle,"\n");
    					}
    					else
    					{
    						$filterCount = 0;
    						for($t = 0; $t < count($filterArray); $t++)
    						{
    							if(in_array($UPNList[$r], $filterArray[$t]))
    								{$filterCount++;}
    						}
    						if($filterCount == count($filterArray))
    						{
    							if($pedigreeCheck == "pedigree")
    							{
    								$sqlPedigreeAll = "SELECT * FROM Pedigree WHERE UPN='".$UPNList[$r]."'";
    								$queryPedigreeAll = mysql_query($sqlPedigreeAll, $connect) or die(mysql_error());
    								while($row = mysql_fetch_assoc($queryPedigreeAll))
    								{
    									extract($row);
    									fwrite($phgcTrialHandle, $row["UPN"]."\t");
    									fwrite($phgcTrialHandle, $row["BirthDate"]."\t");
    									fwrite($phgcTrialHandle, $row["Gender"]."\t");
    									fwrite($phgcTrialHandle, $row["Sire"]."\t");
    									fwrite($phgcTrialHandle, $row["Dam"]."\t");
    									fwrite($phgcTrialHandle, $row["HarvestDate"]."\t");
    									$sqlGetTrial = "SELECT TrialName FROM Trial WHERE Trial_ID='".$row["Trial_ID"]."'";
    									$queryGetTrial = mysql_query($sqlGetTrial, $connect) or die(mysql_error());
    									while($row2 = mysql_fetch_assoc($queryGetTrial))
    									{
    										extract($row2);
    										fwrite($phgcTrialHandle,$row2["TrialName"]."\t");
    									}
    									fwrite($phgcTrialHandle, $row["ProviderPig_ID"]."\t");
    									fwrite($phgcTrialHandle, $row["ExperimentPig_ID"]."\t");
    									fwrite($phgcTrialHandle, $row["PenNumber"]."\t");
    									fwrite($phgcTrialHandle, $row["Litter_ID"]."\t");
    									fwrite($phgcTrialHandle, $row["Farm_ID"]."\t");
    								}
    							}
    							else
    							{
    								fwrite($phgcTrialHandle, $UPNList[$r]."\t");
    							}
    							for($q = 0; $q < count($phenoListArray); $q++)
    							{
    								$sqlPhenoAll = "SELECT * FROM PhenotypeData WHERE PhenoID='".$phenoListArray[$q]."' AND UPN='".$UPNList[$r]."'";
    								$queryPhenoAll = mysql_query($sqlPhenoAll, $connect) or die(mysql_error());
    								while($row = mysql_fetch_assoc($queryPhenoAll))
    								{
    									extract($row);
    									fwrite($phgcTrialHandle, $row["Value"]);
    									$sqlPhenoAllUnits = "SELECT Unit_Type FROM Units WHERE Units_ID='".$row["Units_ID"]."'";
    									$queryPhenoAllUnits = mysql_query($sqlPhenoAllUnits, $connect) or die(mysql_error());
    									while($row2 = mysql_fetch_assoc($queryPhenoAllUnits))
    									{
    										extract($row2);
    										fwrite($phgcTrialHandle, " ".$row2["Unit_Type"]."\t");
    									}
    								}
    							}
    							fwrite($phgcTrialHandle,"\n");
    						}
    					}
    				}
    			}
    		?>
    		<?php
    				if($pedigreeCheck == "pedigree")
    				{
    					$pedigreeFile = '/tmp/Pedigree.'.$TV.'.txt';
      	 				$pedigreeHandle = fopen($pedigreeFile, 'w') or die('Cannot open file: '.$pedigreeFile);
      	 				$sqlPedigreeHeader = "DESCRIBE Pedigree";
  						$queryPedigreeHeader = mysql_query($sqlPedigreeHeader, $connect) or die(mysql_error());
  						while($row = mysql_fetch_assoc($queryPedigreeHeader))
  						{
    						extract($row);
    						$fieldname = $row["Field"];
    						fwrite($pedigreeHandle, $fieldname."\t");
  						} 
  						fwrite($pedigreeHandle, "\n");	
      	 		?>
    		<a href="download.php?currFile=<?php echo $pedigreeFile; ?>" class="btn btn-primary">Download Pedigree</a>	
    		<?php
    				}
    				for($n = 0; $n < count($phenoListArray); $n++)
              		{
              			$tempPheno = str_replace(" ","_",$phenoListArray[$n][1]);
              			$phenotypeFile = '/tmp/'.$tempPheno.$TV.'.txt';
      	 				$phenotypeHandle = fopen($phenotypeFile, 'w') or die('Cannot open file: '.$phenotypeFile);
      	 				$sqlPhenoHeader = "DESCRIBE PhenotypeData";
  						$queryPhenoHeader = mysql_query($sqlPhenoHeader, $connect) or die(mysql_error());
  						while($row = mysql_fetch_assoc($queryPhenoHeader))
  						{
    						extract($row);
    						$fieldname = $row["Field"]; 
    						if(!($fieldname == "PhenoID"))
    							{fwrite($phenotypeHandle, $fieldname."\t");} 
  						}
  						fwrite($phenotypeHandle, "\n");
      	 		?>
      	 	<a href="download.php?currFile=<?php echo $phenotypeFile; ?>" class="btn btn-primary">Download <?php echo $tempPheno; ?></a>
      	 	<?php } ?>
      	 	</div><br/>
            <?php for($m = 0; $m < count($phgcArray); $m++)
              		{
              			$tempPHGC = str_replace(" ","_",$phgcArray[$m][1]);
              			?>	
              			<div class="panel-group" id="<?php echo $tempPHGC; ?>">
    					<div class="panel panel-default">
              			<div class="panel-heading">
              				<h4 class="panel-title">
              					<a class="accordion-toggle" data-toggle="collapse" data-parent="#<?php echo $tempPHGC; ?>" href="#collapse<?php echo $tempPHGC; ?>">
              						<?php echo $phgcArray[$m][1]; ?>
              					</a>
              				</h4>
              			</div>
              			<div id="collapse<?php echo $tempPHGC; ?>" class="accordion-body collapse" style="height: 0px; ">
              			<div class="panel-body">
              			<?php if($pedigreeCheck == "pedigree")
              			{ ?>
              				<div class="panel-group" id="<?php echo $tempPHGC."Pedigree"; ?>">
    						<div class="panel panel-default">
              				<div class="panel-heading"> 
              					<h4 class="panel-title"> 
                					<a class="accordion-toggle" data-toggle="collapse" data-parent="#<?php echo $tempPHGC."Pedigree"; ?>" href="#collapse<?php echo $tempPHGC."Pedigree"; ?>">
      	 								Pedigree
      	 							</a>
      	 						</h4>
              				</div> 
        					<div id="collapse<?php echo $tempPHGC."Pedigree"; ?>" class="accordion-body collapse" style="height: 0px; ">  
                				<div class="panel-body">
        							<table class="table table-bordered">
        								<thead>
        									<tr>
        										<?php 
        											$sqlPedigreeHeader = "DESCRIBE Pedigree";
  
  													$queryPedigreeHeader = mysql_query($sqlPedigreeHeader, $connect) or die(mysql_error());
  													while($row = mysql_fetch_assoc($queryPedigreeHeader))
  													{
    													extract($row);
    													$fieldname = $row["Field"]; ?>
    													<th><?php echo $fieldname; ?></th>
  													<?php } ?>
        									</tr>
										</thead>
										<tbody>
											<?php 
        										$sqlPedigreeBody = "SELECT * FROM Pedigree WHERE Trial_ID='".$phgcArray[$m][0]."'";
  
  												$queryPedigreeBody = mysql_query($sqlPedigreeBody, $connect) or die(mysql_error());
  												while($row = mysql_fetch_assoc($queryPedigreeBody))
  												{
    												extract($row);
    												$tempupn = $row["UPN"]; 
    												$tempbirthdate = $row["BirthDate"];
    													$tempgender = $row["Gender"];
    													$tempsire = $row["Sire"];
    													$tempdam = $row["Dam"];
    													$tempharvestdate = $row["HarvestDate"];
    													$temptrialid = $row["Trial_ID"];
    													$tempproviderpigid = $row["ProviderPig_ID"];
    													$tempexperimentpigid = $row["ExperimentPig_ID"];
    													$temppennumber = $row["PenNumber"];
    													$templitterid = $row["Litter_ID"];
    													$tempfarmid = $row["Farm_ID"];
    													$temptrialname = "";
    													$sqlPedigreeTrial = "SELECT TrialName from Trial WHERE Trial_ID='".$temptrialid."'";
    													$queryPedigreeTrial = mysql_query($sqlPedigreeTrial, $connect) or die(mysql_error());
    													while($row2 = mysql_fetch_assoc($queryPedigreeTrial))
    													{
    														extract($row2);
    														$temptrialname = $row2["TrialName"];
    													}
    													if(in_array("none", $filter_list))
    													{
    														?>
    														<tr>
    															<td><?php echo $tempupn; fwrite($pedigreeHandle, $tempupn."\t"); fwrite($genotypeHandle, $tempupn."\n"); ?></td>
    															<td><?php echo $tempbirthdate; fwrite($pedigreeHandle, $tempbirthdate."\t"); ?></td>
    															<td><?php echo $tempgender; fwrite($pedigreeHandle, $tempgender."\t"); ?></td>
    															<td><?php echo $tempsire; fwrite($pedigreeHandle, $tempsire."\t"); ?></td>
    															<td><?php echo $tempdam; fwrite($pedigreeHandle, $tempdam."\t"); ?></td>
    															<td><?php echo $tempharvestdate; fwrite($pedigreeHandle, $tempharvestdate."\t"); ?></td>
    															<td><?php echo $temptrialname; fwrite($pedigreeHandle, $temptrialname."\t"); ?></td>
    															<td><?php echo $tempproviderpigid; fwrite($pedigreeHandle, $tempproviderpigid."\t"); ?></td>
    															<td><?php echo $tempexperimentpigid; fwrite($pedigreeHandle, $tempexperimentpigid."\t"); ?></td>
    															<td><?php echo $temppennumber; fwrite($pedigreeHandle, $temppennumber."\t"); ?></td>
    															<td><?php echo $templitterid; fwrite($pedigreeHandle, $templitterid."\t"); ?></td>
    															<td><?php echo $tempfarmid; fwrite($pedigreeHandle, $tempfarmid."\n"); ?></td>
    														</tr>
    													<?php }
    													else
    													{
    														$filterCount = 0;
    														for($i = 0; $i < count($filterArray); $i++)
    														{
    															if(in_array($tempupn, $filterArray[$i]))
    																{$filterCount++;}
    														}
    														if($filterCount == count($filterArray))
    														{ ?>
    															<tr>
    																<td><?php echo $tempupn; fwrite($pedigreeHandle, $tempupn."\t"); fwrite($genotypeHandle, $tempupn."\n"); ?></td>
    																<td><?php echo $tempbirthdate; fwrite($pedigreeHandle, $tempbirthdate."\t"); ?></td>
    																<td><?php echo $tempgender; fwrite($pedigreeHandle, $tempgender."\t"); ?></td>
    																<td><?php echo $tempsire; fwrite($pedigreeHandle, $tempsire."\t"); ?></td>
    																<td><?php echo $tempdam; fwrite($pedigreeHandle, $tempdam."\t"); ?></td>
    																<td><?php echo $tempharvestdate; fwrite($pedigreeHandle, $tempharvestdate."\t"); ?></td>
    																<td><?php echo $temptrialname; fwrite($pedigreeHandle, $temptrialname."\t"); ?></td>
    																<td><?php echo $tempproviderpigid; fwrite($pedigreeHandle, $tempproviderpigid."\t"); ?></td>
    																<td><?php echo $tempexperimentpigid; fwrite($pedigreeHandle, $tempexperimentpigid."\t"); ?></td>
    																<td><?php echo $temppennumber; fwrite($pedigreeHandle, $temppennumber."\t");?></td>
    																<td><?php echo $templitterid; fwrite($pedigreeHandle, $templitterid."\t"); ?></td>
    																<td><?php echo $tempfarmid; fwrite($pedigreeHandle, $tempfarmid."\n"); ?></td>
    															</tr>
    														<?php }
    													}
  													} ?>
											</tbody>
        								</table>
          							</div>
          						</div>
          						</div>
    							</div>
              				<?php }
              				for($n = 0; $n < count($phenoListArray); $n++)
              				{
              					$tempPheno = str_replace(" ","_",$phenoListArray[$n][1]); ?> 
              					<div class="panel-group" id="<?php echo $tempPHGC.$tempPheno; ?>">
    							<div class="panel panel-default">
              					<div class="panel-heading">
              					<h4 class="panel-title">  
                					<a class="accordion-toggle" data-toggle="collapse" data-parent="#<?php echo $tempPHGC.$tempPheno; ?>" href="#collapse<?php echo $tempPHGC.$tempPheno; ?>">
      	 								<?php
      	 									echo $phenoListArray[$n][1]; 
      	 									$phenotypeFile = '/tmp/'.$tempPheno.$TV.'.txt';
      	 									$phenotypeHandle = fopen($phenotypeFile, 'a') or die('Cannot open file: '.$phenotypeFile);
      	 								?>
      	 							</a>
      	 						</h4>  
              					</div> 
        						<div id="collapse<?php echo $tempPHGC.$tempPheno; ?>" class="accordion-body collapse" style="height: 0px; ">  
                					<div class="panel-body">
        								<table class="table table-bordered">
        									<thead>
        										<tr>
        											<?php 
        												$sqlPhenoHeader = "DESCRIBE PhenotypeData";
  														$queryPhenoHeader = mysql_query($sqlPhenoHeader, $connect) or die(mysql_error());
  														while($row = mysql_fetch_assoc($queryPhenoHeader))
  														{
    														extract($row);
    														$fieldname = $row["Field"]; 
    														if(!($fieldname == "PhenoID")){ ?>
    														<th><?php echo $fieldname; ?></th>
  															<?php } 
  														} ?>
        										</tr>
											</thead>
											<tbody>
												<?php 
        											$sqlPhenoBody = "SELECT * FROM PhenotypeData WHERE PhenoID='".$phenoListArray[$n][0]."'";
        											$sqlPhenoBody .= "AND UPN in(SELECT p.UPN from Pedigree p where p.Trial_ID='".$phgcArray[$m][0]."') ORDER BY UPN";
  
  													$queryPhenoBody = mysql_query($sqlPhenoBody, $connect) or die(mysql_error());
  													while($row = mysql_fetch_assoc($queryPhenoBody))
  													{
    													extract($row);
    													$tempupn = $row["UPN"]; 
    													$tempdate = $row["Date"];
    													$tempvalue = $row["Value"];
    													$tempunitsid = $row["Units_ID"];
    													$tempunitsname = "";
    													$sqlPhenoUnits = "SELECT Unit_Type from Units WHERE Units_ID='".$tempunitsid."'";
    													$queryPhenoUnits = mysql_query($sqlPhenoUnits, $connect) or die(mysql_error());
    													while($row3 = mysql_fetch_assoc($queryPhenoUnits))
    													{
    														extract($row3);
    														$tempunitsname = $row3["Unit_Type"];
    													}
    													if(in_array("none", $filter_list))
    													{
    														?>
    														<tr>
    															<td><?php echo $tempupn; fwrite($phenotypeHandle, $tempupn."\t"); fwrite($genotypeHandle, $tempupn."\n"); ?></td>
    															<td><?php echo $tempdate; fwrite($phenotypeHandle, $tempdate."\t"); ?></td>
    															<td><?php echo $tempvalue; fwrite($phenotypeHandle, $tempvalue."\t"); ?></td>
    															<td><?php echo $tempunitsname; fwrite($phenotypeHandle, $tempunitsname."\n"); ?></td>
    														</tr>
    													<?php }
    													else
    													{
    														$filterCount = 0;
    														for($i = 0; $i < count($filterArray); $i++)
    														{
    															if(in_array($tempupn, $filterArray[$i]))
    																{$filterCount++;}
    														}
    														if($filterCount == count($filterArray))
    														{ ?>
    															<tr>
    																<td><?php echo $tempupn; fwrite($phenotypeHandle, $tempupn."\t"); fwrite($genotypeHandle, $tempupn."\n"); ?></td>
    																<td><?php echo $tempdate; fwrite($phenotypeHandle, $tempdate."\t"); ?></td>
    																<td><?php echo $tempvalue; fwrite($phenotypeHandle, $tempvalue."\t"); ?></td>
    																<td><?php echo $tempunitsname; fwrite($phenotypeHandle, $tempunitsname."\n"); ?></td>
    															</tr>
    														<?php }
    													}
  													} ?>
											</tbody>
        								</table>
          							</div>
          						</div>
          						</div>
          						</div>
              				<?php } ?>
              				</div>
              				</div>
              				</div>
              				</div>
              			<?php } } ?>
          			</div>
          		</div>
      	</div>
	</div>
</div>
<?php include('includes/footer.inc.php'); ?>
</body>
</html>