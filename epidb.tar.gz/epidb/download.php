<?php
session_start();
  
if(isset($_GET['currFile']))
{
  $fullpath = $_GET['currFile'];
  
  if($fd = fopen($fullpath, "r"))
  {
    $fsize = filesize($fullpath);
    $path_parts = pathinfo($fullpath);
    $ext = strtolower($path_parts["extension"]);
    switch ($ext)
    {
      case "zip":
      header("Content-type: application/zip");
      header("Content-Disposition: attachment; filename=\"".$path_parts["basename"]."\"");
      break;
      default;
      header("Content-type: application/octet-stream");
      header("Content-Disposition: filename=\"".$path_parts["basename"]."\"");
    }
    header("Content-length: $fsize");
    header("Cache-control: private");
    while(!feof($fd))
    {
      $buffer = fread($fd, 2048);
      echo $buffer;
    }
  }
  fclose($fd);
  exit;
}